/*
# Add location capture columns to riders and guarantors

1. Modified Tables
- `riders`: Added columns to store the rider's geolocation at time of submission
  - location_lat (double precision, nullable)
  - location_lng (double precision, nullable)
  - location_accuracy (double precision, nullable) — accuracy in meters from the geolocation API
- `guarantors`: Added columns to store the guarantor's geolocation at time of submission
  - location_lat (double precision, nullable)
  - location_lng (double precision, nullable)
  - location_accuracy (double precision, nullable)

2. Security
- No changes — existing RLS policies and grants already cover these columns (anon + authenticated CRUD).
*/

ALTER TABLE riders
  ADD COLUMN IF NOT EXISTS location_lat double precision,
  ADD COLUMN IF NOT EXISTS location_lng double precision,
  ADD COLUMN IF NOT EXISTS location_accuracy double precision;

ALTER TABLE guarantors
  ADD COLUMN IF NOT EXISTS location_lat double precision,
  ADD COLUMN IF NOT EXISTS location_lng double precision,
  ADD COLUMN IF NOT EXISTS location_accuracy double precision;
