/*
# Create Rider Application & Guarantor Schema

1. New Tables
- `riders`: Stores dispatch rider applications with personal info, KYC (NIN), document/video storage URLs, and skills.
  - id (uuid PK)
  - full_name (text)
  - phone_number (text)
  - residential_address (text)
  - emergency_contact_name (text)
  - emergency_contact_phone (text)
  - skills_experience (text)
  - nin (text)
  - nin_document_path (text) — storage path for NIN slip photo
  - video_path (text) — storage path for verification video
  - status (text, default 'pending')
  - created_at (timestamptz)

- `guarantors`: Stores guarantor entries linked to a rider, each with a unique single-use verification token.
  - id (uuid PK)
  - rider_id (uuid FK → riders, ON DELETE CASCADE)
  - name (text)
  - phone_number (text)
  - verification_token (uuid, unique, gen_random_uuid) — single-use link token
  - status (text, default 'pending') — pending | submitted | expired
  - submitted_at (timestamptz, nullable)
  - created_at (timestamptz)

2. Storage
- Create public bucket `rider-uploads` for NIN document photos and verification videos.
- Allow anon + authenticated to upload and read within this bucket (public form, no sign-in).

3. Security
- Enable RLS on both tables.
- Grant CRUD to anon + authenticated (no sign-in public form).
- Storage policies: anon + authenticated can INSERT and SELECT on `rider-uploads` bucket.
- Guarantor tokens are single-use: the `verification_token` is unique and `status` prevents reuse.
*/

-- ===== Riders Table =====
CREATE TABLE IF NOT EXISTS riders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  phone_number text NOT NULL,
  residential_address text NOT NULL,
  emergency_contact_name text NOT NULL,
  emergency_contact_phone text NOT NULL,
  skills_experience text,
  nin text NOT NULL,
  nin_document_path text,
  video_path text,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE riders ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON riders TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_riders" ON riders;
CREATE POLICY "anon_select_riders" ON riders FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_riders" ON riders;
CREATE POLICY "anon_insert_riders" ON riders FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_riders" ON riders;
CREATE POLICY "anon_update_riders" ON riders FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_riders" ON riders;
CREATE POLICY "anon_delete_riders" ON riders FOR DELETE
  TO anon, authenticated USING (true);

-- ===== Guarantors Table =====
CREATE TABLE IF NOT EXISTS guarantors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rider_id uuid NOT NULL REFERENCES riders(id) ON DELETE CASCADE,
  name text NOT NULL,
  phone_number text NOT NULL,
  verification_token uuid UNIQUE DEFAULT gen_random_uuid(),
  status text NOT NULL DEFAULT 'pending',
  submitted_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE guarantors ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON guarantors TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_guarantors" ON guarantors;
CREATE POLICY "anon_select_guarantors" ON guarantors FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_guarantors" ON guarantors;
CREATE POLICY "anon_insert_guarantors" ON guarantors FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_guarantors" ON guarantors;
CREATE POLICY "anon_update_guarantors" ON guarantors FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_guarantors" ON guarantors;
CREATE POLICY "anon_delete_guarantors" ON guarantors FOR DELETE
  TO anon, authenticated USING (true);

-- ===== Storage Bucket =====
INSERT INTO storage.buckets (id, name, public)
VALUES ('rider-uploads', 'rider-uploads', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies
DROP POLICY IF EXISTS "anon_upload_rider_uploads" ON storage.objects;
CREATE POLICY "anon_upload_rider_uploads" ON storage.objects FOR INSERT
  TO anon, authenticated WITH CHECK (bucket_id = 'rider-uploads');

DROP POLICY IF EXISTS "anon_read_rider_uploads" ON storage.objects;
CREATE POLICY "anon_read_rider_uploads" ON storage.objects FOR SELECT
  TO anon, authenticated USING (bucket_id = 'rider-uploads');

DROP POLICY IF EXISTS "anon_update_rider_uploads" ON storage.objects;
CREATE POLICY "anon_update_rider_uploads" ON storage.objects FOR UPDATE
  TO anon, authenticated USING (bucket_id = 'rider-uploads') WITH CHECK (bucket_id = 'rider-uploads');

DROP POLICY IF EXISTS "anon_delete_rider_uploads" ON storage.objects;
CREATE POLICY "anon_delete_rider_uploads" ON storage.objects FOR DELETE
  TO anon, authenticated USING (bucket_id = 'rider-uploads');
