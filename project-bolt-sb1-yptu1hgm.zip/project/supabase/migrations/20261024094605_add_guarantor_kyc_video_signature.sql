/*
# Add guarantor KYC, video, and signature columns

1. Modified Tables
- `guarantors`: Added columns for the full guarantor verification flow
  - nin (text, nullable) — Guarantor's National Identification Number
  - nin_document_path (text, nullable) — Storage path for NIN document photo
  - video_path (text, nullable) — Storage path for guarantor video declaration
  - digital_signature (text, nullable) — Data URL of the drawn signature or typed name

2. Security
- No changes — existing RLS policies and grants already cover these columns (anon + authenticated CRUD).
*/

ALTER TABLE guarantors
  ADD COLUMN IF NOT EXISTS nin text,
  ADD COLUMN IF NOT EXISTS nin_document_path text,
  ADD COLUMN IF NOT EXISTS video_path text,
  ADD COLUMN IF NOT EXISTS digital_signature text;
