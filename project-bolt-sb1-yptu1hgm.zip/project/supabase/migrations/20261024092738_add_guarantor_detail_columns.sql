/*
# Add guarantor submission detail columns

1. Modified Tables
- `guarantors`: Added columns to capture the full guarantor verification response
  - guarantor_address (text, nullable) — residential address provided by guarantor
  - guarantor_phone_confirmed (text, nullable) — phone number confirmed/updated by guarantor
  - relationship (text, nullable) — relationship to the rider
  - occupation (text, nullable) — guarantor's occupation
  - confirmation (boolean, nullable) — whether guarantor accepted responsibility

2. Security
- No changes — existing RLS policies and grants already cover these columns (anon + authenticated CRUD).
*/

ALTER TABLE guarantors
  ADD COLUMN IF NOT EXISTS guarantor_address text,
  ADD COLUMN IF NOT EXISTS guarantor_phone_confirmed text,
  ADD COLUMN IF NOT EXISTS relationship text,
  ADD COLUMN IF NOT EXISTS occupation text,
  ADD COLUMN IF NOT EXISTS confirmation boolean;
