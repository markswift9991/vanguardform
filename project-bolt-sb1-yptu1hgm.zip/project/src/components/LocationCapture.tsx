import { useState, useCallback, useEffect } from "react";
import { MapPin, Loader2, CheckCircle2, AlertCircle, RefreshCw } from "lucide-react";

export interface LocationData {
  lat: number;
  lng: number;
  accuracy: number;
}

interface LocationCaptureProps {
  onLocation: (loc: LocationData | null) => void;
  value?: LocationData | null;
}

type Status = "idle" | "loading" | "granted" | "denied" | "unsupported";

export function LocationCapture({ onLocation, value }: LocationCaptureProps) {
  const [status, setStatus] = useState<Status>(value ? "granted" : "idle");
  const [location, setLocation] = useState<LocationData | null>(value ?? null);
  const [error, setError] = useState<string | null>(null);

  const requestLocation = useCallback(() => {
    if (!navigator.geolocation) {
      setStatus("unsupported");
      setError("Location services are not supported on this device.");
      return;
    }
    setStatus("loading");
    setError(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const loc: LocationData = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
        };
        setLocation(loc);
        setStatus("granted");
        onLocation(loc);
      },
      (err) => {
        let msg = "Could not access your location. Please grant location permission.";
        if (err.code === err.PERMISSION_DENIED) {
          msg = "Location permission was denied. Please enable location access in your browser settings and try again.";
        } else if (err.code === err.POSITION_UNAVAILABLE) {
          msg = "Your location is currently unavailable. Try again or move to an open area.";
        } else if (err.code === err.TIMEOUT) {
          msg = "Location request timed out. Please try again.";
        }
        setStatus("denied");
        setError(msg);
        onLocation(null);
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  }, [onLocation]);

  useEffect(() => {
    // Do not auto-request; let the user explicitly grant permission
  }, []);

  const handleRetry = () => {
    requestLocation();
  };

  return (
    <div className={`rounded-2xl border p-6 transition ${status === "granted" ? "border-emerald-200 bg-emerald-50/50" : status === "denied" || status === "unsupported" ? "border-red-200 bg-red-50/50" : "border-slate-200 bg-slate-50"}`}>
      <div className="flex items-start gap-4">
        <div className={`flex h-12 w-12 flex-none items-center justify-center rounded-xl ${status === "granted" ? "bg-emerald-100 text-emerald-600" : status === "denied" || status === "unsupported" ? "bg-red-100 text-red-600" : "bg-brand-100 text-brand-600"}`}>
          {status === "loading" ? (
            <Loader2 className="h-6 w-6 animate-spin" />
          ) : status === "granted" ? (
            <CheckCircle2 className="h-6 w-6" />
          ) : status === "denied" || status === "unsupported" ? (
            <AlertCircle className="h-6 w-6" />
          ) : (
            <MapPin className="h-6 w-6" />
          )}
        </div>

        <div className="flex-1 min-w-0">
          <h3 className="text-sm font-bold text-slate-800">Location Verification</h3>
          {status === "idle" && (
            <>
              <p className="mt-1 text-sm text-slate-500">
                You must grant location permission before you can submit this form. Your location
                will be recorded securely as part of the verification process.
              </p>
              <button
                type="button"
                onClick={requestLocation}
                className="mt-3 inline-flex items-center gap-2 rounded-xl bg-brand-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-brand-700"
              >
                <MapPin className="h-4 w-4" />
                Grant Location Access
              </button>
            </>
          )}

          {status === "loading" && (
            <p className="mt-1 text-sm text-slate-500">Detecting your location...</p>
          )}

          {status === "granted" && location && (
            <>
              <p className="mt-1 text-sm text-emerald-700">
                Location captured successfully. This is required to submit the form.
              </p>
              <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
                <LocationStat label="Latitude" value={location.lat.toFixed(5)} />
                <LocationStat label="Longitude" value={location.lng.toFixed(5)} />
                <LocationStat label="Accuracy" value={`±${Math.round(location.accuracy)}m`} />
              </div>
              <button
                type="button"
                onClick={handleRetry}
                className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-brand-600 transition hover:text-brand-700"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Update location
              </button>
            </>
          )}

          {(status === "denied" || status === "unsupported") && (
            <>
              <p className="mt-1 text-sm text-red-700">{error}</p>
              <button
                type="button"
                onClick={requestLocation}
                className="mt-3 inline-flex items-center gap-2 rounded-xl border border-red-200 bg-white px-4 py-2.5 text-sm font-semibold text-red-600 transition hover:bg-red-50"
              >
                <RefreshCw className="h-4 w-4" />
                Try Again
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function LocationStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-white px-3 py-2">
      <p className="text-xs font-medium text-slate-400">{label}</p>
      <p className="text-sm font-bold text-slate-700 tabular-nums">{value}</p>
    </div>
  );
}
