export function Signature() {
  return (
    <div className="flex items-center justify-center gap-2 py-8 text-center">
      <div className="h-px w-12 bg-slate-300" />
      <p className="text-sm font-semibold tracking-wide text-slate-500">
        Vanguard Velocity Delivery
      </p>
      <div className="h-px w-12 bg-slate-300" />
    </div>
  );
}
