import { useRef, useState, useEffect, useCallback } from "react";
import { Video, Play, Pause, RotateCcw, X, AlertCircle, CheckCircle2, Circle } from "lucide-react";

interface VideoVerificationProps {
  onRecorded: (file: File) => void;
  videoUrl?: string;
  script: string;
  targetSeconds?: number;
}

const TARGET_SECONDS = 10;

export function VideoVerification({ onRecorded, videoUrl, script, targetSeconds = TARGET_SECONDS }: VideoVerificationProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  const [streamActive, setStreamActive] = useState(false);
  const [recording, setRecording] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [starting, setStarting] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | undefined>(videoUrl);
  const [playing, setPlaying] = useState(false);

  const stopStream = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setStreamActive(false);
  }, []);

  const clearTimer = useCallback(() => {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const startCamera = useCallback(async () => {
    setStarting(true);
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 640 }, height: { ideal: 480 } },
        audio: true,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setStreamActive(true);
    } catch {
      setError("Could not access the camera and microphone. Please grant permissions and try again.");
    } finally {
      setStarting(false);
    }
  }, []);

  const stopRecording = useCallback(() => {
    clearTimer();
    setRecording(false);
    if (recorderRef.current && recorderRef.current.state !== "inactive") {
      recorderRef.current.stop();
    }
  }, [clearTimer]);

  const startRecording = useCallback(() => {
    chunksRef.current = [];
    setElapsed(0);
    let mime = "video/webm";
    if (typeof MediaRecorder !== "undefined") {
      const candidates = ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm", "video/mp4"];
      for (const c of candidates) {
        if (MediaRecorder.isTypeSupported(c)) {
          mime = c;
          break;
        }
      }
    }
    try {
      const recorder = new MediaRecorder(streamRef.current!, { mimeType: mime });
      recorderRef.current = recorder;
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: mime });
        const url = URL.createObjectURL(blob);
        setPreviewUrl(url);
        const ext = mime.includes("mp4") ? "mp4" : "webm";
        const file = new File([blob], `rider-verification-${Date.now()}.${ext}`, { type: blob.type });
        onRecorded(file);
        stopStream();
      };
      recorder.start();
      setRecording(true);
      timerRef.current = window.setInterval(() => {
        setElapsed((prev) => {
          const next = prev + 1;
          if (next >= targetSeconds) {
            stopRecording();
          }
          return next;
        });
      }, 1000);
    } catch {
      setError("Video recording is not supported on this device.");
    }
  }, [onRecorded, stopRecording, stopStream]);

  const retake = useCallback(() => {
    setPreviewUrl(undefined);
    onRecorded(new File([], "clear"));
    startCamera();
  }, [onRecorded, startCamera]);

  useEffect(() => {
    return () => {
      clearTimer();
      stopStream();
    };
  }, [clearTimer, stopStream]);

  const progressPct = Math.min((elapsed / targetSeconds) * 100, 100);

  if (previewUrl) {
    return (
      <div className="space-y-4">
        <div className="relative overflow-hidden rounded-xl border border-slate-200 bg-black">
          <video
            src={previewUrl}
            controls
            className="max-h-80 w-full object-contain"
            onPlay={() => setPlaying(true)}
            onPause={() => setPlaying(false)}
          />
          <div className="absolute left-3 top-3 flex items-center gap-1.5 rounded-lg bg-emerald-500/90 px-3 py-1.5 text-xs font-semibold text-white">
            <CheckCircle2 className="h-3.5 w-3.5" /> Recorded
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={retake}
            className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
          >
            <RotateCcw className="h-4 w-4" />
            Record Again
          </button>
        </div>
        <p className="text-xs text-slate-500">
          Review the video above. If you're happy with it, continue to the next step. You can re-record
          as many times as needed.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Script prompt */}
      <div className="rounded-xl bg-brand-50 border border-brand-100 px-4 py-4">
        <div className="flex items-center gap-2 text-brand-700 mb-2">
          <Video className="h-4 w-4" />
          <span className="text-xs font-bold uppercase tracking-wider">Read this aloud on camera</span>
        </div>
        <p className="text-sm leading-relaxed text-slate-700">
          "{script}"
        </p>
      </div>

      {/* Camera viewport */}
      <div className="relative overflow-hidden rounded-xl border border-slate-200 bg-slate-900 aspect-video flex items-center justify-center">
        {streamActive ? (
          <video ref={videoRef} playsInline muted className="h-full w-full object-cover" />
        ) : (
          <div className="flex flex-col items-center gap-3 text-slate-400">
            <Video className="h-10 w-10" />
            <p className="text-sm">{starting ? "Starting camera..." : "Camera will appear here"}</p>
          </div>
        )}

        {streamActive && !recording && (
          <button
            type="button"
            onClick={stopStream}
            className="absolute right-3 top-3 rounded-lg bg-black/50 p-1.5 text-white transition hover:bg-black/70"
            aria-label="Close camera"
          >
            <X className="h-4 w-4" />
          </button>
        )}

        {recording && (
          <>
            <div className="absolute left-3 top-3 flex items-center gap-1.5 rounded-lg bg-red-600 px-3 py-1.5 text-xs font-bold text-white">
              <Circle className="h-3 w-3 fill-current animate-pulse" />
              REC {Math.floor(elapsed / 60)}:{(elapsed % 60).toString().padStart(2, "0")}
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-white/20">
              <div
                className="h-full bg-amber-400 transition-all duration-500"
                style={{ width: `${progressPct}%` }}
              />
            </div>
          </>
        )}
      </div>

      {error && (
        <div className="flex items-start gap-2 rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-700">
          <AlertCircle className="mt-0.5 h-4 w-4 flex-none" />
          <span>{error}</span>
        </div>
      )}

      <div className="flex items-center gap-2">
        {!streamActive ? (
          <button
            type="button"
            onClick={startCamera}
            disabled={starting}
            className="inline-flex items-center gap-2 rounded-xl bg-brand-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-brand-700 disabled:opacity-60"
          >
            <Video className="h-4 w-4" />
            {starting ? "Starting..." : "Open Camera"}
          </button>
        ) : !recording ? (
          <button
            type="button"
            onClick={startRecording}
            className="inline-flex items-center gap-2 rounded-xl bg-red-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-red-700"
          >
            <Circle className="h-3 w-3 fill-current" />
            Start Recording
          </button>
        ) : (
          <button
            type="button"
            onClick={stopRecording}
            className="inline-flex items-center gap-2 rounded-xl bg-slate-700 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-slate-800"
          >
            {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            Stop & Save ({elapsed}s / {targetSeconds}s)
          </button>
        )}
      </div>

      <p className="text-xs text-slate-400">
        Recording stops automatically at {targetSeconds} seconds. Speak clearly and ensure your face
        is visible throughout.
      </p>
    </div>
  );
}
