import { Truck, Phone, Mail, MapPin, Fuel, User, Building2, ShieldCheck } from "lucide-react";

export function RiderHeader() {
  return (
    <header className="animate-fade-in">
      {/* Identity bar */}
      <div className="rounded-2xl bg-gradient-to-br from-brand-700 to-brand-900 p-6 sm:p-8 text-white shadow-soft">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            <div className="flex h-14 w-14 flex-none items-center justify-center rounded-2xl bg-white/10 ring-1 ring-white/20">
              <Truck className="h-7 w-7 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-extrabold tracking-tight sm:text-2xl">
                Vanguard Velocity Delivery
              </h1>
              <p className="text-sm text-brand-100">Dispatch Rider Application</p>
            </div>
          </div>
          <div className="flex flex-col gap-1.5 text-sm text-brand-100 sm:text-right">
            <a href="tel:+2348000000000" className="flex items-center gap-2 sm:justify-end hover:text-white transition">
              <Phone className="h-4 w-4" /> +234 800 000 0000
            </a>
            <a href="mailto:info@vanguardvelocity.com" className="flex items-center gap-2 sm:justify-end hover:text-white transition">
              <Mail className="h-4 w-4" /> info@vanguardvelocity.com
            </a>
            <span className="flex items-center gap-2 sm:justify-end">
              <MapPin className="h-4 w-4" /> Lagos, Nigeria
            </span>
          </div>
        </div>
      </div>

      {/* Earnings breakdown */}
      <div className="mt-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
        <h2 className="mb-4 text-base font-bold text-slate-800">Earnings Breakdown</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <EarningCard icon={<Fuel className="h-5 w-5" />} label="Petrol" pct={30} color="bg-amber-500" />
          <EarningCard icon={<User className="h-5 w-5" />} label="Rider" pct={30} color="bg-emerald-500" />
          <EarningCard icon={<Building2 className="h-5 w-5" />} label="Company" pct={30} color="bg-brand-600" />
          <EarningCard icon={<ShieldCheck className="h-5 w-5" />} label="NIN / Reserve" pct={10} color="bg-violet-500" />
        </div>
        {/* Stacked bar */}
        <div className="mt-4 flex h-3 overflow-hidden rounded-full">
          <div className="bg-amber-500" style={{ width: "30%" }} />
          <div className="bg-emerald-500" style={{ width: "30%" }} />
          <div className="bg-brand-600" style={{ width: "30%" }} />
          <div className="bg-violet-500" style={{ width: "10%" }} />
        </div>
      </div>

      {/* Work policy */}
      <div className="mt-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
        <div className="flex items-start gap-3">
          <div className="flex h-10 w-10 flex-none items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 ring-1 ring-emerald-100">
            <ShieldCheck className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-800">Work Policy</h2>
            <p className="mt-1 text-sm leading-relaxed text-slate-600">
              Riders are permitted to accept orders from third-party platforms (Uber, Glovo, InDrive, etc.)
              and work offline, provided all orders are logged on their registered company account.
            </p>
          </div>
        </div>
      </div>
    </header>
  );
}

function EarningCard({
  icon,
  label,
  pct,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  pct: number;
  color: string;
}) {
  return (
    <div className="rounded-xl border border-slate-100 bg-slate-50 p-4 transition hover:shadow-soft">
      <div className="flex items-center gap-2 mb-2">
        <div className={`flex h-8 w-8 items-center justify-center rounded-lg ${color} text-white`}>
          {icon}
        </div>
        <span className="text-sm font-semibold text-slate-700">{label}</span>
      </div>
      <div className="flex items-baseline gap-1">
        <span className="text-2xl font-extrabold text-slate-800">{pct}</span>
        <span className="text-sm font-semibold text-slate-400">%</span>
      </div>
    </div>
  );
}
