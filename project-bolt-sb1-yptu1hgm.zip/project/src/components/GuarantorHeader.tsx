import { Truck, Phone, Mail, MapPin, Scale } from "lucide-react";

interface GuarantorHeaderProps {
  riderName: string;
}

export function GuarantorHeader({ riderName }: GuarantorHeaderProps) {
  return (
    <header className="animate-fade-in space-y-4">
      {/* Identity bar */}
      <div className="rounded-2xl bg-gradient-to-br from-brand-700 to-brand-900 p-6 sm:p-8 text-white shadow-soft">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            <div className="flex h-14 w-14 flex-none items-center justify-center rounded-2xl bg-white/10 ring-1 ring-white/20">
              <Truck className="h-7 w-7 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-extrabold tracking-tight sm:text-2xl">
                Vanguard Velocity Delivery
              </h1>
              <p className="text-sm text-brand-100">Guarantor Verification Form</p>
            </div>
          </div>
          <div className="flex flex-col gap-1.5 text-sm text-brand-100 sm:text-right">
            <a href="tel:+2348000000000" className="flex items-center gap-2 sm:justify-end hover:text-white transition">
              <Phone className="h-4 w-4" /> +234 800 000 0000
            </a>
            <a href="mailto:info@vanguardvelocity.com" className="flex items-center gap-2 sm:justify-end hover:text-white transition">
              <Mail className="h-4 w-4" /> info@vanguardvelocity.com
            </a>
            <span className="flex items-center gap-2 sm:justify-end">
              <MapPin className="h-4 w-4" /> Lagos, Nigeria
            </span>
          </div>
        </div>
      </div>

      {/* Legal declaration */}
      <div className="rounded-2xl border border-red-200 bg-red-50 p-6 shadow-soft">
        <div className="flex items-start gap-3">
          <div className="flex h-10 w-10 flex-none items-center justify-center rounded-xl bg-red-100 text-red-600 ring-1 ring-red-200">
            <Scale className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-red-800">Legal Declaration</h2>
            <p className="mt-1.5 text-sm leading-relaxed text-red-700">
              By filling out this form, you, as the guarantor, legally vouch for the integrity of{" "}
              <span className="font-bold">{riderName}</span> and accept full financial and legal liability
              for any breach, damages, or non-compliance that may arise during their engagement as a
              dispatch rider with Vanguard Velocity Delivery. This declaration is binding and will be
              used as part of the company's verification process.
            </p>
          </div>
        </div>
      </div>
    </header>
  );
}
