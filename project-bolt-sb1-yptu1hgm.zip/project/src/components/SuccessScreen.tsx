import { useState } from "react";
import { CheckCircle2, Copy, Share2, Link2, MessageCircle, ArrowRight, Truck } from "lucide-react";
import { Signature } from "./Signature";
import { GuarantorFormPreview } from "./GuarantorFormPreview";

export interface GuarantorLinkInfo {
  guarantorName: string;
  guarantorPhone: string;
  riderName: string;
  link: string;
}

interface SuccessScreenProps {
  riderName: string;
  links: GuarantorLinkInfo[];
  onNewApplication: () => void;
}

export function SuccessScreen({ riderName, links, onNewApplication }: SuccessScreenProps) {
  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <div className="animate-scale-in rounded-2xl border border-emerald-200 bg-white p-8 text-center shadow-soft">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50 ring-8 ring-emerald-50/50">
          <CheckCircle2 className="h-9 w-9 text-emerald-500" />
        </div>
        <h1 className="text-2xl font-extrabold text-slate-800">Application Submitted!</h1>
        <p className="mt-2 text-sm text-slate-500">
          Thank you, {riderName}. Your rider profile has been saved. Share the unique guarantor
          verification links below — each link is single-use.
        </p>
      </div>

      <div className="space-y-4">
        {links.map((item, i) => (
          <GuarantorLinkCard key={i} info={item} index={i + 1} />
        ))}
      </div>

      <div className="rounded-xl bg-brand-50 border border-brand-100 px-5 py-4">
        <p className="text-sm text-brand-800">
          Send each link to the named guarantor. They'll complete a short confirmation form. Once both
          guarantors submit, your application review begins.
        </p>
      </div>

      {/* Guarantor form preview */}
      <GuarantorFormPreview links={links} />

      <button
        type="button"
        onClick={onNewApplication}
        className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-6 py-3.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 sm:w-auto"
      >
        Submit Another Application
        <ArrowRight className="h-4 w-4" />
      </button>

      <Signature />
    </div>
  );
}

function GuarantorLinkCard({ info, index }: { info: GuarantorLinkInfo; index: number }) {
  const [copied, setCopied] = useState(false);

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(info.link);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback
      const ta = document.createElement("textarea");
      ta.value = info.link;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    }
  };

  const whatsappUrl = `https://wa.me/${info.guarantorPhone.replace(/\D/g, "")}?text=${encodeURIComponent(
    `Hello ${info.guarantorName}, ${info.riderName} has listed you as a guarantor for a dispatch rider application at Vanguard Velocity Delivery. Please complete the verification form here: ${info.link}`
  )}`;

  return (
    <div className="animate-fade-in rounded-2xl border border-slate-200 bg-white p-5 shadow-soft">
      <div className="mb-3 flex items-center gap-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-50 text-sm font-bold text-brand-600 ring-1 ring-brand-100">
          {index}
        </div>
        <div className="flex-1 min-w-0">
          <p className="truncate text-sm font-bold text-slate-800">{info.guarantorName}</p>
          <p className="truncate text-xs text-slate-400">{info.guarantorPhone}</p>
        </div>
        <Truck className="h-5 w-5 text-slate-300" />
      </div>

      <div className="flex items-center gap-2 rounded-xl bg-slate-50 border border-slate-200 px-3 py-2.5">
        <Link2 className="h-4 w-4 flex-none text-slate-400" />
        <input
          readOnly
          value={info.link}
          className="flex-1 truncate bg-transparent text-xs text-slate-600 focus:outline-none"
          onFocus={(e) => e.target.select()}
        />
      </div>

      <div className="mt-3 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={copyLink}
          className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
        >
          {copied ? <CheckCircle2 className="h-4 w-4 text-emerald-500" /> : <Copy className="h-4 w-4" />}
          {copied ? "Copied!" : "Copy Link"}
        </button>
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-700"
        >
          <MessageCircle className="h-4 w-4" />
          Share via WhatsApp
        </a>
        <a
          href={info.link}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
        >
          <Share2 className="h-4 w-4" />
          Open
        </a>
      </div>
    </div>
  );
}
