import { useState, useRef } from "react";
import { Truck, Loader2, AlertCircle, CheckCircle2, User, IdCard, Video, ShieldCheck, Lock, PenLine, MapPin } from "lucide-react";
import { Field, TextInput } from "./Field";
import { SectionCard } from "./SectionCard";
import { Signature } from "./Signature";
import { GuarantorHeader } from "./GuarantorHeader";
import { CameraPhotoCapture } from "./CameraPhotoCapture";
import { VideoVerification } from "./VideoVerification";
import { SignaturePad } from "./SignaturePad";
import { LocationCapture, type LocationData } from "./LocationCapture";
import type { GuarantorSubmission } from "../types";

interface GuarantorFormProps {
  token: string;
  riderName: string;
  guarantorName: string;
  guarantorPhone: string;
  onSubmit: (submission: GuarantorSubmission) => Promise<void>;
}

export function GuarantorForm({ token, riderName, guarantorName, guarantorPhone, onSubmit }: GuarantorFormProps) {
  const [values, setValues] = useState<GuarantorSubmission>({
    guarantor_name: guarantorName,
    guarantor_phone: guarantorPhone,
    guarantor_address: "",
    relationship: "",
    occupation: "",
    nin: "",
    nin_document: null,
    video: null,
    digital_signature: "",
    confirmation: false,
    location_lat: null,
    location_lng: null,
    location_accuracy: null,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [ninPreview, setNinPreview] = useState<string | undefined>();
  const [videoUrl, setVideoUrl] = useState<string | undefined>();
  const [location, setLocation] = useState<LocationData | null>(null);
  const scrollRef = useRef<HTMLFormElement>(null);

  const set = <K extends keyof GuarantorSubmission>(key: K, val: GuarantorSubmission[K]) => {
    setValues((prev) => ({ ...prev, [key]: val }));
    setErrors((prev) => {
      if (!prev[key]) return prev;
      const n = { ...prev };
      delete n[key];
      return n;
    });
  };

  const handleNinCapture = (file: File) => {
    if (file.size === 0) {
      set("nin_document", null);
      setNinPreview(undefined);
      return;
    }
    set("nin_document", file);
    setNinPreview(URL.createObjectURL(file));
  };

  const handleVideoRecorded = (file: File) => {
    if (file.size === 0) {
      set("video", null);
      setVideoUrl(undefined);
      return;
    }
    set("video", file);
    setVideoUrl(URL.createObjectURL(file));
  };

  const handleLocation = (loc: LocationData | null) => {
    if (loc) {
      setLocation(loc);
      set("location_lat", loc.lat);
      set("location_lng", loc.lng);
      set("location_accuracy", loc.accuracy);
    } else {
      setLocation(null);
      set("location_lat", null);
      set("location_lng", null);
      set("location_accuracy", null);
    }
  };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!values.guarantor_name.trim()) e.guarantor_name = "Name is required";
    if (!values.guarantor_phone.trim()) e.guarantor_phone = "Phone is required";
    else if (!/^\+?\d[\d\s-]{6,}$/.test(values.guarantor_phone)) e.guarantor_phone = "Enter a valid phone number";
    if (!values.guarantor_address.trim()) e.guarantor_address = "Address is required";
    if (!values.relationship.trim()) e.relationship = "Relationship is required";
    if (!values.occupation.trim()) e.occupation = "Occupation is required";
    if (!values.nin.trim()) e.nin = "NIN is required";
    else if (!/^\d{11}$/.test(values.nin.trim())) e.nin = "NIN must be 11 digits";
    if (!values.nin_document) e.nin_document = "Please capture or upload your NIN document";
    if (!values.video) e.video = "Please record your video declaration";
    if (!values.digital_signature) e.digital_signature = "Please sign in the pad above";
    if (!values.confirmation) e.confirmation = "You must confirm to submit";
    if (!values.location_lat || !values.location_lng) e.location = "Location permission is required to submit this form";
    setErrors(e);
    if (Object.keys(e).length > 0) {
      scrollRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    setSubmitError(null);
    if (!validate()) return;
    setSubmitting(true);
    try {
      await onSubmit(values);
      setDone(true);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : "Submission failed. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const declarationScript = `My name is ${values.guarantor_name || "[Guarantor Name]"}. I am the guarantor for ${riderName}. I confirm I know them personally, vouch for their integrity, and accept full legal liability and responsibility for them while operating with Vanguard Velocity Delivery.`;

  if (done) {
    return (
      <div className="mx-auto max-w-xl space-y-5">
        <div className="animate-scale-in rounded-2xl border border-emerald-200 bg-white p-8 text-center shadow-soft">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50 ring-8 ring-emerald-50/50">
            <CheckCircle2 className="h-9 w-9 text-emerald-500" />
          </div>
          <h1 className="text-2xl font-extrabold text-slate-800">Verification Complete</h1>
          <p className="mt-2 text-sm text-slate-500">
            Thank you, {values.guarantor_name}. Your guarantor confirmation for {riderName} has been
            submitted and locked to Vanguard Velocity Delivery.
          </p>
        </div>
        <div className="flex items-center justify-center gap-2 rounded-xl bg-slate-100 px-4 py-3 text-sm font-medium text-slate-500">
          <Lock className="h-4 w-4" />
          This form is now locked and cannot be edited again.
        </div>
        <Signature />
      </div>
    );
  }

  return (
    <form ref={scrollRef} onSubmit={handleSubmit} className="space-y-5">
      <GuarantorHeader riderName={riderName} />

      {/* Location capture — required before submission */}
      <LocationCapture onLocation={handleLocation} value={location} />
      {errors.location && (
        <div className="flex items-start gap-2 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700 -mt-2">
          <MapPin className="mt-0.5 h-5 w-5 flex-none" />
          <span>{errors.location}</span>
        </div>
      )}

      {/* Step 1: Guarantor Information */}
      <SectionCard step={1} title="Guarantor Information" subtitle="Confirm or update your details" icon={<User className="h-5 w-5" />}>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Full Name" required error={errors.guarantor_name}>
            <TextInput value={values.guarantor_name} onChange={(v) => set("guarantor_name", v)} placeholder="Your full name" hasError={!!errors.guarantor_name} />
          </Field>
          <Field label="Phone Number" required error={errors.guarantor_phone}>
            <TextInput value={values.guarantor_phone} onChange={(v) => set("guarantor_phone", v)} placeholder="Your phone number" hasError={!!errors.guarantor_phone} />
          </Field>
          <div className="sm:col-span-2">
            <Field label="Residential Address" required error={errors.guarantor_address}>
              <TextInput value={values.guarantor_address} onChange={(v) => set("guarantor_address", v)} placeholder="Street, city, state" hasError={!!errors.guarantor_address} />
            </Field>
          </div>
          <Field label="Relationship to Rider" required error={errors.relationship} hint={`Vouching for: ${riderName}`}>
            <TextInput value={values.relationship} onChange={(v) => set("relationship", v)} placeholder="e.g. Employer, Family, Friend" hasError={!!errors.relationship} />
          </Field>
          <Field label="Occupation" required error={errors.occupation}>
            <TextInput value={values.occupation} onChange={(v) => set("occupation", v)} placeholder="e.g. Business Owner, Teacher" hasError={!!errors.occupation} />
          </Field>
        </div>
      </SectionCard>

      {/* Step 2: KYC */}
      <SectionCard step={2} title="KYC & Identity Verification" subtitle="National Identification Number (NIN)" icon={<IdCard className="h-5 w-5" />}>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="NIN (National Identification Number)" required error={errors.nin} hint="11-digit number">
            <TextInput value={values.nin} onChange={(v) => set("nin", v)} placeholder="12345678901" maxLength={11} hasError={!!errors.nin} />
          </Field>
          <div className="sm:col-span-2">
            <Field label="NIN Document / ID Photo" required error={errors.nin_document} hint="Use your camera to scan, or upload an image of your NIN ID">
              <CameraPhotoCapture onCapture={handleNinCapture} capturedPreview={ninPreview} />
            </Field>
          </div>
        </div>
      </SectionCard>

      {/* Step 3: Video Declaration */}
      <SectionCard step={3} title="Video Declaration" subtitle="Record a short video (5-10 seconds) reading the statement below" icon={<Video className="h-5 w-5" />}>
        {errors.video && <p className="mb-3 text-xs font-medium text-red-500">{errors.video}</p>}
        <VideoVerification
          onRecorded={handleVideoRecorded}
          videoUrl={videoUrl}
          script={declarationScript}
        />
      </SectionCard>

      {/* Step 4: Digital Signature & Locking */}
      <SectionCard step={4} title="Digital Signature & Confirmation" subtitle="Sign below and confirm to lock your submission" icon={<PenLine className="h-5 w-5" />}>
        <Field label="Draw your signature" required error={errors.digital_signature}>
          <SignaturePad onSignature={(url) => set("digital_signature", url)} value={values.digital_signature} />
        </Field>

        <div className="mt-5">
          <label className={`flex cursor-pointer items-start gap-3 rounded-xl border p-4 transition ${errors.confirmation ? "border-red-300 bg-red-50/50" : "border-slate-200 bg-slate-50 hover:bg-slate-100"}`}>
            <input
              type="checkbox"
              checked={values.confirmation}
              onChange={(e) => set("confirmation", e.target.checked)}
              className="mt-0.5 h-5 w-5 flex-none rounded accent-brand-600"
            />
            <span className="text-sm leading-relaxed text-slate-600">
              I confirm that the information and video provided are accurate, my signature is binding, and
              I accept full legal and financial liability for {riderName} while they operate as a dispatch
              rider with Vanguard Velocity Delivery. I understand this form will be locked upon submission
              and cannot be edited.
            </span>
          </label>
          {errors.confirmation && <p className="mt-2 text-xs font-medium text-red-500">{errors.confirmation}</p>}
        </div>
      </SectionCard>

      {submitError && (
        <div className="flex items-start gap-2 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">
          <AlertCircle className="mt-0.5 h-5 w-5 flex-none" />
          <span>{submitError}</span>
        </div>
      )}

      <div className="flex flex-col items-center gap-3 pb-2">
        <button
          type="submit"
          disabled={submitting || !location}
          className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-brand-600 px-6 py-4 text-base font-bold text-white shadow-soft transition hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-70 sm:w-auto sm:px-12"
        >
          {submitting ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" /> Submitting...
            </>
          ) : !location ? (
            <>
              <MapPin className="h-5 w-5" /> Grant Location to Submit
            </>
          ) : (
            <>
              <ShieldCheck className="h-5 w-5" /> Confirm, Sign & Lock
            </>
          )}
        </button>
        <p className="flex items-center gap-1.5 text-xs text-slate-400">
          {location ? (
            <>
              <Lock className="h-3.5 w-3.5" /> Once submitted, this form is permanently locked
            </>
          ) : (
            <>
              <MapPin className="h-3.5 w-3.5" /> Location access is required to submit
            </>
          )}
        </p>
      </div>

      <Signature />
    </form>
  );
}
