import { useState, useRef } from "react";
import { User, IdCard, Video, Users, Loader2, Send, AlertCircle, CheckCircle2, MapPin } from "lucide-react";
import { SectionCard } from "./SectionCard";
import { Field, TextInput, TextArea } from "./Field";
import { CameraPhotoCapture } from "./CameraPhotoCapture";
import { VideoVerification } from "./VideoVerification";
import { Signature } from "./Signature";
import { LocationCapture, type LocationData } from "./LocationCapture";
import type { GuarantorInput } from "../types";

export interface RiderFormValues {
  full_name: string;
  phone_number: string;
  residential_address: string;
  emergency_contact_name: string;
  emergency_contact_phone: string;
  skills_experience: string;
  nin: string;
  nin_document: File | null;
  video: File | null;
  guarantor1: GuarantorInput;
  guarantor2: GuarantorInput;
  location_lat: number | null;
  location_lng: number | null;
  location_accuracy: number | null;
}

interface RiderFormProps {
  onSubmit: (values: RiderFormValues) => Promise<void>;
}

const emptyGuarantor: GuarantorInput = { name: "", phone_number: "" };

export function RiderForm({ onSubmit }: RiderFormProps) {
  const [values, setValues] = useState<RiderFormValues>({
    full_name: "",
    phone_number: "",
    residential_address: "",
    emergency_contact_name: "",
    emergency_contact_phone: "",
    skills_experience: "",
    nin: "",
    nin_document: null,
    video: null,
    guarantor1: { ...emptyGuarantor },
    guarantor2: { ...emptyGuarantor },
    location_lat: null,
    location_lng: null,
    location_accuracy: null,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [ninPreview, setNinPreview] = useState<string | undefined>();
  const [videoUrl, setVideoUrl] = useState<string | undefined>();
  const [location, setLocation] = useState<LocationData | null>(null);
  const [locationError, setLocationError] = useState(false);
  const scrollRef = useRef<HTMLFormElement>(null);

  const set = <K extends keyof RiderFormValues>(key: K, val: RiderFormValues[K]) => {
    setValues((prev) => ({ ...prev, [key]: val }));
    setErrors((prev) => {
      if (!prev[key]) return prev;
      const next = { ...prev };
      delete next[key];
      return next;
    });
  };

  const handleNinCapture = (file: File) => {
    if (file.size === 0) {
      set("nin_document", null);
      setNinPreview(undefined);
      return;
    }
    set("nin_document", file);
    setNinPreview(URL.createObjectURL(file));
  };

  const handleVideoRecorded = (file: File) => {
    if (file.size === 0) {
      set("video", null);
      setVideoUrl(undefined);
      return;
    }
    set("video", file);
    setVideoUrl(URL.createObjectURL(file));
  };

  const handleLocation = (loc: LocationData | null) => {
    if (loc) {
      setLocation(loc);
      setLocationError(false);
      set("location_lat", loc.lat);
      set("location_lng", loc.lng);
      set("location_accuracy", loc.accuracy);
    } else {
      setLocation(null);
      setLocationError(true);
      set("location_lat", null);
      set("location_lng", null);
      set("location_accuracy", null);
    }
  };

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (!values.full_name.trim()) e.full_name = "Full name is required";
    if (!values.phone_number.trim()) e.phone_number = "Phone number is required";
    else if (!/^\+?\d[\d\s-]{6,}$/.test(values.phone_number)) e.phone_number = "Enter a valid phone number";
    if (!values.residential_address.trim()) e.residential_address = "Residential address is required";
    if (!values.emergency_contact_name.trim()) e.emergency_contact_name = "Emergency contact name is required";
    if (!values.emergency_contact_phone.trim()) e.emergency_contact_phone = "Emergency contact phone is required";
    else if (!/^\+?\d[\d\s-]{6,}$/.test(values.emergency_contact_phone)) e.emergency_contact_phone = "Enter a valid phone number";
    if (!values.nin.trim()) e.nin = "NIN is required";
    else if (!/^\d{11}$/.test(values.nin.trim())) e.nin = "NIN must be 11 digits";
    if (!values.nin_document) e.nin_document = "Please capture or upload your NIN document";
    if (!values.video) e.video = "Please record your verification video";
    if (!values.guarantor1.name.trim() || !values.guarantor1.phone_number.trim())
      e.guarantor1 = "Both guarantor fields are required";
    if (!values.guarantor2.name.trim() || !values.guarantor2.phone_number.trim())
      e.guarantor2 = "Both guarantor fields are required";
    if (!values.location_lat || !values.location_lng) e.location = "Location permission is required to submit this form";
    setErrors(e);
    if (Object.keys(e).length > 0) {
      scrollRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    setSubmitError(null);
    if (!validate()) return;
    setSubmitting(true);
    try {
      await onSubmit(values);
    } catch (err) {
      setSubmitError(
        err instanceof Error ? err.message : "Something went wrong submitting your application. Please try again."
      );
      setSubmitting(false);
    }
  };

  return (
    <form ref={scrollRef} onSubmit={handleSubmit} className="space-y-5">
      {/* Location capture — required before submission */}
      <LocationCapture onLocation={handleLocation} value={location} />
      {errors.location && (
        <div className="flex items-start gap-2 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700 -mt-2">
          <MapPin className="mt-0.5 h-5 w-5 flex-none" />
          <span>{errors.location}</span>
        </div>
      )}

      {/* Step 1: Personal Info */}
      <SectionCard step={1} title="Personal Information & Skills" subtitle="Tell us about yourself" icon={<User className="h-5 w-5" />}>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Full Name" required error={errors.full_name}>
            <TextInput value={values.full_name} onChange={(v) => set("full_name", v)} placeholder="e.g. John Doe" hasError={!!errors.full_name} />
          </Field>
          <Field label="Phone Number" required error={errors.phone_number}>
            <TextInput value={values.phone_number} onChange={(v) => set("phone_number", v)} placeholder="e.g. +234 801 234 5678" hasError={!!errors.phone_number} />
          </Field>
          <Field label="Residential Address" required error={errors.residential_address}>
            <TextInput value={values.residential_address} onChange={(v) => set("residential_address", v)} placeholder="Street, city, state" hasError={!!errors.residential_address} />
          </Field>
          <div className="grid gap-5 sm:grid-cols-1">
            <Field label="Emergency Contact Name" required error={errors.emergency_contact_name}>
              <TextInput value={values.emergency_contact_name} onChange={(v) => set("emergency_contact_name", v)} placeholder="Next of kin full name" hasError={!!errors.emergency_contact_name} />
            </Field>
          </div>
          <Field label="Emergency Contact Phone" required error={errors.emergency_contact_phone}>
            <TextInput value={values.emergency_contact_phone} onChange={(v) => set("emergency_contact_phone", v)} placeholder="e.g. +234 801 234 5678" hasError={!!errors.emergency_contact_phone} />
          </Field>
          <div className="sm:col-span-2">
            <Field label="Skills & Experience" hint="Relevant skills, previous delivery experience, vehicle types, etc.">
              <TextArea value={values.skills_experience} onChange={(v) => set("skills_experience", v)} placeholder="e.g. 2 years dispatch riding, familiar with Lagos routes, motorcycle license..." rows={4} />
            </Field>
          </div>
        </div>
      </SectionCard>

      {/* Step 2: KYC */}
      <SectionCard step={2} title="KYC & Identity Verification" subtitle="National Identification Number (NIN)" icon={<IdCard className="h-5 w-5" />}>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="NIN (National Identification Number)" required error={errors.nin} hint="11-digit number">
            <TextInput value={values.nin} onChange={(v) => set("nin", v)} placeholder="12345678901" maxLength={11} hasError={!!errors.nin} />
          </Field>
          <div className="sm:col-span-2">
            <Field label="NIN Document / Slip Photo" required error={errors.nin_document} hint="Use your camera to scan, or upload an image of your NIN slip">
              <CameraPhotoCapture onCapture={handleNinCapture} capturedPreview={ninPreview} />
            </Field>
          </div>
        </div>
      </SectionCard>

      {/* Step 3: Video Verification */}
      <SectionCard step={3} title="Video Verification" subtitle="Record a short video (5-10 seconds) reading the statement below" icon={<Video className="h-5 w-5" />}>
        {errors.video && <p className="mb-3 text-xs font-medium text-red-500">{errors.video}</p>}
        <VideoVerification
          onRecorded={handleVideoRecorded}
          videoUrl={videoUrl}
          script={`My name is ${values.full_name || "[Full Name]"}. My NIN is ${values.nin || "[NIN Number]"}. I am applying as a dispatch rider for Vanguard Velocity Delivery, and I agree to take full liability and responsibility for the vehicle assigned to me under company rules.`}
        />
      </SectionCard>

      {/* Step 4: Guarantors */}
      <SectionCard step={4} title="Guarantor Information" subtitle="Provide two guarantors. Unique verification links will be generated for each." icon={<Users className="h-5 w-5" />}>
        <div className="grid gap-5 sm:grid-cols-2">
          <div className="rounded-xl border border-slate-100 bg-slate-50 p-5">
            <p className="mb-4 text-xs font-bold uppercase tracking-wider text-brand-600">Guarantor 1</p>
            <div className="space-y-4">
              <Field label="Full Name" required error={errors.guarantor1}>
                <TextInput value={values.guarantor1.name} onChange={(v) => set("guarantor1", { ...values.guarantor1, name: v })} placeholder="Guarantor full name" hasError={!!errors.guarantor1} />
              </Field>
              <Field label="Phone Number" required>
                <TextInput value={values.guarantor1.phone_number} onChange={(v) => set("guarantor1", { ...values.guarantor1, phone_number: v })} placeholder="e.g. +234 801 234 5678" hasError={!!errors.guarantor1} />
              </Field>
            </div>
          </div>
          <div className="rounded-xl border border-slate-100 bg-slate-50 p-5">
            <p className="mb-4 text-xs font-bold uppercase tracking-wider text-brand-600">Guarantor 2</p>
            <div className="space-y-4">
              <Field label="Full Name" required error={errors.guarantor2}>
                <TextInput value={values.guarantor2.name} onChange={(v) => set("guarantor2", { ...values.guarantor2, name: v })} placeholder="Guarantor full name" hasError={!!errors.guarantor2} />
              </Field>
              <Field label="Phone Number" required>
                <TextInput value={values.guarantor2.phone_number} onChange={(v) => set("guarantor2", { ...values.guarantor2, phone_number: v })} placeholder="e.g. +234 801 234 5678" hasError={!!errors.guarantor2} />
              </Field>
            </div>
          </div>
        </div>
      </SectionCard>

      {/* Submit */}
      {submitError && (
        <div className="flex items-start gap-2 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">
          <AlertCircle className="mt-0.5 h-5 w-5 flex-none" />
          <span>{submitError}</span>
        </div>
      )}

      <div className="flex flex-col items-center gap-3 pb-2">
        <button
          type="submit"
          disabled={submitting || !location}
          className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-brand-600 px-6 py-4 text-base font-bold text-white shadow-soft transition hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-70 sm:w-auto sm:px-12"
        >
          {submitting ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" /> Submitting...
            </>
          ) : !location ? (
            <>
              <MapPin className="h-5 w-5" /> Grant Location to Submit
            </>
          ) : (
            <>
              <Send className="h-5 w-5" /> Submit Application
            </>
          )}
        </button>
        <p className="flex items-center gap-1.5 text-xs text-slate-400">
          {location ? (
            <>
              <CheckCircle2 className="h-3.5 w-3.5" /> Your information is stored securely
            </>
          ) : (
            <>
              <MapPin className="h-3.5 w-3.5" /> Location access is required to submit
            </>
          )}
        </p>
      </div>

      <Signature />
    </form>
  );
}
