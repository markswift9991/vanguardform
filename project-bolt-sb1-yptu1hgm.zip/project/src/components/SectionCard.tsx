import type { ReactNode } from "react";

interface SectionCardProps {
  step?: number;
  title: string;
  subtitle?: string;
  children: ReactNode;
  icon?: ReactNode;
}

export function SectionCard({ step, title, subtitle, children, icon }: SectionCardProps) {
  return (
    <section className="animate-fade-in rounded-2xl border border-slate-200 bg-white shadow-soft">
      <div className="flex items-start gap-4 border-b border-slate-100 px-6 py-5 sm:px-8">
        {step !== undefined && (
          <div className="flex h-10 w-10 flex-none items-center justify-center rounded-xl bg-brand-50 text-base font-bold text-brand-600 ring-1 ring-brand-100">
            {step}
          </div>
        )}
        {icon && (
          <div className="flex h-10 w-10 flex-none items-center justify-center rounded-xl bg-brand-50 text-brand-600 ring-1 ring-brand-100">
            {icon}
          </div>
        )}
        <div>
          <h2 className="text-lg font-bold text-slate-800">{title}</h2>
          {subtitle && <p className="mt-0.5 text-sm text-slate-500">{subtitle}</p>}
        </div>
      </div>
      <div className="px-6 py-6 sm:px-8">{children}</div>
    </section>
  );
}
