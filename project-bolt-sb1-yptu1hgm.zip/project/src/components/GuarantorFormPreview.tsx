import { useState } from "react";
import { Eye, Lock, User, IdCard, Video, PenLine, MapPin, ExternalLink, ChevronDown, ChevronUp, Scale, Truck, Phone, Mail, MapPin as MapPinIcon } from "lucide-react";
import { Signature } from "./Signature";
import type { GuarantorLinkInfo } from "./SuccessScreen";

interface GuarantorFormPreviewProps {
  links: GuarantorLinkInfo[];
}

export function GuarantorFormPreview({ links }: GuarantorFormPreviewProps) {
  const [expanded, setExpanded] = useState(false);
  const [activeLink, setActiveLink] = useState<number>(0);

  return (
    <div className="animate-fade-in rounded-2xl border border-slate-200 bg-white shadow-soft overflow-hidden">
      {/* Header */}
      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        className="flex w-full items-center justify-between px-6 py-5 text-left transition hover:bg-slate-50"
      >
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-50 text-brand-600 ring-1 ring-brand-100">
            <Eye className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-800">Preview the Guarantor Form</h2>
            <p className="text-sm text-slate-500">
              See what your guarantors will see. Share the links below to let them fill it out.
            </p>
          </div>
        </div>
        {expanded ? (
          <ChevronUp className="h-5 w-5 text-slate-400 flex-none" />
        ) : (
          <ChevronDown className="h-5 w-5 text-slate-400 flex-none" />
        )}
      </button>

      {expanded && (
        <div className="border-t border-slate-100">
          {/* Link selector tabs */}
          <div className="flex gap-2 px-6 pt-4">
            {links.map((link, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setActiveLink(i)}
                className={`inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold transition ${activeLink === i ? "bg-brand-600 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}
              >
                Guarantor {i + 1}
                <span className="truncate max-w-24 text-xs opacity-80">— {link.guarantorName}</span>
              </button>
            ))}
          </div>

          <div className="px-6 py-4">
            <div className="flex items-center gap-2 rounded-xl bg-brand-50 border border-brand-100 px-4 py-3">
              <Lock className="h-4 w-4 flex-none text-brand-600" />
              <p className="text-sm text-brand-800">
                This is a read-only preview. Only the guarantor holding this link can fill it out.
              </p>
              <a
                href={links[activeLink].link}
                target="_blank"
                rel="noopener noreferrer"
                className="ml-auto inline-flex items-center gap-1.5 rounded-lg bg-brand-600 px-3 py-1.5 text-xs font-semibold text-white transition hover:bg-brand-700 flex-none"
              >
                Open Form <ExternalLink className="h-3 w-3" />
              </a>
            </div>
          </div>

          {/* Read-only preview of the guarantor form */}
          <div className="px-6 pb-6 space-y-4">
            {/* Mini header */}
            <div className="rounded-xl bg-gradient-to-br from-brand-700 to-brand-900 p-4 text-white">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 flex-none items-center justify-center rounded-xl bg-white/10 ring-1 ring-white/20">
                  <Truck className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="text-sm font-extrabold">Vanguard Velocity Delivery</p>
                  <p className="text-xs text-brand-100">Guarantor Verification Form</p>
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-3 text-xs text-brand-100">
                <span className="flex items-center gap-1"><Phone className="h-3 w-3" /> +234 800 000 0000</span>
                <span className="flex items-center gap-1"><Mail className="h-3 w-3" /> info@vanguardvelocity.com</span>
                <span className="flex items-center gap-1"><MapPinIcon className="h-3 w-3" /> Lagos, Nigeria</span>
              </div>
            </div>

            {/* Legal declaration */}
            <div className="rounded-xl border border-red-200 bg-red-50 p-4">
              <div className="flex items-start gap-2">
                <Scale className="h-4 w-4 flex-none text-red-600 mt-0.5" />
                <p className="text-xs leading-relaxed text-red-700">
                  <span className="font-bold">Legal Declaration:</span> By filling out this form, you
                  legally vouch for the integrity of <span className="font-bold">{links[activeLink].riderName}</span> and
                  accept full financial and legal liability for any breach, damages, or non-compliance
                  during their engagement as a dispatch rider.
                </p>
              </div>
            </div>

            {/* Location capture (locked) */}
            <PreviewSection icon={<MapPin className="h-4 w-4" />} title="Location Verification" locked>
              <div className="flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs text-slate-400">
                <MapPin className="h-3.5 w-3.5" />
                The guarantor must grant location access before submitting
              </div>
            </PreviewSection>

            {/* Step 1: Guarantor Information */}
            <PreviewSection step={1} icon={<User className="h-4 w-4" />} title="Guarantor Information" locked>
              <div className="grid grid-cols-2 gap-3">
                <PreviewField label="Full Name" value={links[activeLink].guarantorName} />
                <PreviewField label="Phone Number" value={links[activeLink].guarantorPhone} />
                <PreviewField label="Residential Address" placeholder="To be filled by guarantor" />
                <PreviewField label="Relationship to Rider" placeholder="e.g. Employer, Family" hint={`Vouching for: ${links[activeLink].riderName}`} />
                <PreviewField label="Occupation" placeholder="e.g. Business Owner" />
              </div>
            </PreviewSection>

            {/* Step 2: KYC */}
            <PreviewSection step={2} icon={<IdCard className="h-4 w-4" />} title="KYC & Identity Verification" locked>
              <div className="grid grid-cols-2 gap-3">
                <PreviewField label="NIN" placeholder="11-digit number" />
                <div className="col-span-2">
                  <PreviewField label="NIN Document / ID Photo" placeholder="Camera scan or upload" />
                </div>
              </div>
            </PreviewSection>

            {/* Step 3: Video Declaration */}
            <PreviewSection step={3} icon={<Video className="h-4 w-4" />} title="Video Declaration" locked>
              <div className="rounded-lg bg-brand-50 border border-brand-100 px-3 py-2.5">
                <p className="text-xs italic leading-relaxed text-slate-600">
                  "My name is {links[activeLink].guarantorName || "[Guarantor Name]"}. I am the guarantor
                  for {links[activeLink].riderName}. I confirm I know them personally, vouch for their
                  integrity, and accept full legal liability and responsibility for them while operating
                  with Vanguard Velocity Delivery."
                </p>
              </div>
            </PreviewSection>

            {/* Step 4: Digital Signature */}
            <PreviewSection step={4} icon={<PenLine className="h-4 w-4" />} title="Digital Signature & Confirmation" locked>
              <div className="flex items-center gap-2 rounded-lg border-2 border-dashed border-slate-200 bg-slate-50 px-3 py-6 text-xs text-slate-400">
                <PenLine className="h-4 w-4" />
                Signature pad — guarantor signs here
              </div>
              <div className="mt-2 flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs text-slate-400">
                <Lock className="h-3.5 w-3.5" />
                Checkbox + submit locks the form permanently
              </div>
            </PreviewSection>
          </div>
        </div>
      )}
    </div>
  );
}

function PreviewSection({
  step,
  icon,
  title,
  locked,
  children,
}: {
  step?: number;
  icon: React.ReactNode;
  title: string;
  locked?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-xl border border-slate-200 bg-slate-50/50">
      <div className="flex items-center gap-3 border-b border-slate-100 px-4 py-3">
        {step !== undefined && (
          <span className="flex h-7 w-7 flex-none items-center justify-center rounded-lg bg-brand-50 text-xs font-bold text-brand-600 ring-1 ring-brand-100">
            {step}
          </span>
        )}
        {!step && (
          <span className="flex h-7 w-7 flex-none items-center justify-center rounded-lg bg-brand-50 text-brand-600 ring-1 ring-brand-100">
            {icon}
          </span>
        )}
        <h3 className="text-sm font-bold text-slate-700">{title}</h3>
        {locked && <Lock className="ml-auto h-3.5 w-3.5 text-slate-300" />}
      </div>
      <div className="px-4 py-3">{children}</div>
    </div>
  );
}

function PreviewField({
  label,
  value,
  placeholder,
  hint,
}: {
  label: string;
  value?: string;
  placeholder?: string;
  hint?: string;
}) {
  return (
    <div className="space-y-1">
      <p className="text-xs font-semibold text-slate-500">{label}</p>
      {hint && <p className="text-[10px] text-slate-400">{hint}</p>}
      <div className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs text-slate-600">
        {value || <span className="text-slate-300">{placeholder}</span>}
      </div>
    </div>
  );
}
