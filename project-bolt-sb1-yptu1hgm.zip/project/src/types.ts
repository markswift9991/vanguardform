export interface GuarantorInput {
  name: string;
  phone_number: string;
}

export interface RiderData {
  id?: string;
  full_name: string;
  phone_number: string;
  residential_address: string;
  emergency_contact_name: string;
  emergency_contact_phone: string;
  skills_experience: string;
  nin: string;
  nin_document_path?: string;
  video_path?: string;
}

export interface GuarantorRecord {
  id: string;
  rider_id: string;
  name: string;
  phone_number: string;
  verification_token: string;
  status: string;
  submitted_at: string | null;
  created_at: string;
}

export interface GuarantorSubmission {
  guarantor_name: string;
  guarantor_phone: string;
  guarantor_address: string;
  relationship: string;
  occupation: string;
  nin: string;
  nin_document: File | null;
  video: File | null;
  digital_signature: string;
  confirmation: boolean;
  location_lat: number | null;
  location_lng: number | null;
  location_accuracy: number | null;
}
