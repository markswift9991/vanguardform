import "dotenv/config";
import { hash } from "bcryptjs";
import { pool, isDatabaseConfigured, missingDatabaseConfig } from "./db.mjs";

if (!isDatabaseConfigured) {
  console.error(`Aiven connection is not configured. Check ${missingDatabaseConfig.join(", ")}.`);
  process.exit(1);
}

const email = process.argv[2]?.trim().toLowerCase();
if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
  console.error("Usage: npm run admin:create -- admin@example.com");
  process.exit(1);
}

const input = process.stdin;
const output = process.stdout;
if (!input.isTTY || typeof input.setRawMode !== "function") {
  console.error("Run this command in an interactive terminal to enter the admin password securely.");
  process.exit(1);
}

output.write("Admin password (12+ characters): ");
input.setRawMode(true);
input.resume();
input.setEncoding("utf8");
let password = "";

const onData = async (character) => {
  if (character === "\u0003") {
    input.setRawMode(false);
    process.exit(130);
  }
  if (character === "\r" || character === "\n") {
    input.setRawMode(false);
    input.pause();
    input.removeListener("data", onData);
    output.write("\n");
    if (password.length < 12) {
      console.error("Password must be at least 12 characters.");
      await pool.end();
      process.exit(1);
    }
    try {
      const passwordHash = await hash(password, 12);
      await pool.query(
        `insert into admin_users (email, password_hash)
         values ($1, $2)
         on conflict (email) do update set password_hash = excluded.password_hash`,
        [email, passwordHash],
      );
      await pool.query(
        "delete from admin_sessions where admin_user_id = (select id from admin_users where email = $1)",
        [email],
      );
      console.log(`Administrator ${email} is ready.`);
    } catch (error) {
      console.error("Could not create administrator.", { code: error.code || "unexpected_error" });
      process.exitCode = 1;
    } finally {
      password = "";
      await pool.end();
    }
    return;
  }
  if (character === "\u007f" || character === "\b") {
    password = password.slice(0, -1);
    return;
  }
  if (character >= " ") password += character;
};

input.on("data", onData);