import "dotenv/config";
import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import pg from "pg";

const { Pool } = pg;
const defaultCaPath = resolve("server/certs/aiven-ca.pem");
const caPath = process.env.PG_CA_CERT_PATH
  ? resolve(process.env.PG_CA_CERT_PATH)
  : defaultCaPath;
const requiredEnvironment = ["PGHOST", "PGDATABASE", "PGUSER", "PGPASSWORD"];
export const missingDatabaseConfig = requiredEnvironment.filter((key) => !process.env[key]);
if (!existsSync(caPath)) missingDatabaseConfig.push("PG_CA_CERT_PATH");
export const isDatabaseConfigured = missingDatabaseConfig.length === 0;

const sslCa = isDatabaseConfigured ? readFileSync(caPath, "utf8") : undefined;
export const pool = isDatabaseConfigured
  ? new Pool({
      host: process.env.PGHOST,
      port: Number(process.env.PGPORT || 25042),
      database: process.env.PGDATABASE,
      user: process.env.PGUSER,
      password: process.env.PGPASSWORD,
      ssl: { ca: sslCa, rejectUnauthorized: true },
      max: 10,
    })
  : null;

pool?.on("error", (error) => {
  console.error("Unexpected Aiven database pool error", { code: error.code || "database_error" });
});
