import "dotenv/config";
import { readFile, readdir } from "node:fs/promises";
import { resolve } from "node:path";
import { isDatabaseConfigured, missingDatabaseConfig, pool } from "./db.mjs";

if (!isDatabaseConfigured) {
  console.error(`Aiven connection is not configured. Check ${missingDatabaseConfig.join(", ")}.`);
  process.exit(1);
}

const migrationDirectory = resolve("server/migrations");
const migrationFiles = (await readdir(migrationDirectory))
  .filter((filename) => /^\d{3}_[a-z0-9_]+\.sql$/.test(filename))
  .sort();
const client = await pool.connect();

try {
  await client.query(
    `create table if not exists schema_migrations (
       version text primary key,
       applied_at timestamptz not null default now()
     )`,
  );

  for (const filename of migrationFiles) {
    const version = filename.slice(0, -4);
    const { rows: applied } = await client.query(
      "select version from schema_migrations where version = $1",
      [version],
    );
    if (applied.length) {
      console.log(`Migration ${version} is already applied.`);
      continue;
    }

    if (version === "001_initial") {
      const { rows: existing } = await client.query(
        `select to_regclass('public.riders') as riders,
                to_regclass('public.guarantors') as guarantors,
                to_regclass('public.admin_users') as admin_users`,
      );
      if (Object.values(existing[0]).some(Boolean)) {
        throw new Error("Target tables already exist without this migration record; refusing to alter an unverified database.");
      }
    }

    await client.query("begin");
    try {
      const migrationSql = await readFile(resolve(migrationDirectory, filename), "utf8");
      await client.query(migrationSql);
      await client.query("insert into schema_migrations (version) values ($1)", [version]);
      await client.query("commit");
      console.log(`Migration ${version} applied successfully.`);
    } catch (error) {
      await client.query("rollback");
      throw error;
    }
  }
} catch (error) {
  console.error("Aiven schema migration failed.", { code: error.code || "migration_error", message: error.message });
  process.exitCode = 1;
} finally {
  client.release();
  await pool.end();
}
