# cPanel deployment

This bundle runs the built React site and its Express API together on one Node.js
application, so browser requests to `/api` stay on the same domain.

## 1. Create the cPanel Node.js application

1. In **Setup Node.js App**, create an application using Node.js 20 or newer.
2. Set the application root to the directory where this archive is extracted.
3. Set the startup file to `app.js`.
4. Set `NODE_ENV` to `production`. cPanel should provide the application port.
5. Upload and extract this archive into the application root.
6. In the cPanel application page, run **NPM Install**. If using Terminal instead,
   run `npm ci --omit=dev` from the application root.
7. Restart the application after installation and after any environment changes.

The archive's `dist/.htaccess` includes an Apache fallback so direct browser
visits to routes such as `/admin/login` serve the SPA instead of a web-server
404. The Express server serves both the frontend and `/api` from one origin.
Do not copy only `dist/` into `public_html` as a static-only website: then the
frontend loads but Apache returns 404 for all API requests.

Set the cPanel Node.js application's **Application URL** to the
`riderapplicationform` subdomain at its root path (`/`), not `/api` or another
subpath. Extract the full archive into the configured application root, set
`app.js` as the startup file, install dependencies, configure the database
environment, and restart the application. Keep `dist/.htaccess`; the Node app
must own the same subdomain as the forms so `/api` requests reach Express.

## 2. Configure the database

Set these server-side environment variables in cPanel (or in a `.env` file in
the application root if your cPanel Node.js setup loads dotenv):

- `PGHOST`: your Aiven PostgreSQL hostname
- `PGPORT`: your Aiven PostgreSQL port
- `PGDATABASE`: your database name
- `PGUSER`: your database user
- `PGPASSWORD`: your current rotated database password
- `PG_CA_CERT_PATH`: `server/certs/aiven-ca.pem`
- `NODE_ENV`: `production`

The supplied CA certificate is included. TLS certificate verification is enabled;
do not disable it. Keep the database password server-side, and never add it to a
`VITE_` variable or commit it into the archive.

From cPanel Terminal, in the application root, apply the migrations:

```sh
npm run db:migrate
```

This safely applies the numbered PostgreSQL migrations, including the logo
storage table. The complete schema is also provided in `server/schema.sql`.
Do not run the migrations against a different database than the one configured
in cPanel.

## 3. Start and verify

Restart the Node.js application in cPanel. Verify:

- `https://your-domain.example/` displays the rider application.
- `https://your-domain.example/api/health` returns a healthy status.
- `https://your-domain.example/admin/login` displays the administrator sign-in.
- After signing in, upload the company logo under Form content. The public
  `/api/company-logo` endpoint should return the image, not a 404.

Create the first administrator from `/admin/login` only while no administrator
exists. Once created, additional administrator accounts must be created by a
signed-in administrator.

### Troubleshooting an HTML 404 on login

The message “API returned text/html instead of JSON (HTTP 404)” means Apache
is serving the frontend, but `/api` is not reaching the Express application.
This is a cPanel domain-to-Node-app routing issue, not an admin password or
database schema error. Confirm the Node.js app is assigned to the exact same
subdomain at `/`, with `app.js` as its startup file, then restart it. Open
`https://your-domain.example/api/health` directly: it must return JSON. A JSON
`503` means Express is reachable but database configuration/schema needs
attention; an HTML 404 means the domain is still not routed to the Node app.

## Bundle contents

- `dist/`: production frontend assets
- `server/`: Express API, database connection, CA certificate, migrations, and
  full PostgreSQL schema
- `app.js`: cPanel-compatible production entry point
- `package.json` and `package-lock.json`: production dependencies and scripts
- `.env.example`: safe configuration template with no password

The archive intentionally excludes `.env`, `node_modules`, source maps, and
development-only packages.
