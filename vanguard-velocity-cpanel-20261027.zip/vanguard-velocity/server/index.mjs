import "dotenv/config";
import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";
import { resolve } from "node:path";
import { compare, hash } from "bcryptjs";
import express from "express";
import multer from "multer";
import { isDatabaseConfigured, missingDatabaseConfig, pool } from "./db.mjs";

const app = express();
const port = Number(process.env.PORT || 3001);
const sessionCookie = "vanguard_admin_session";
const sessionDurationSeconds = 60 * 60 * 12;
const loginAttempts = new Map();
const telegramEncryptionKey = () => {
  const encoded = process.env.TELEGRAM_SETTINGS_ENCRYPTION_KEY;
  if (!encoded) return null;
  const key = Buffer.from(encoded, "base64");
  return key.length === 32 ? key : null;
};
const statuses = new Set(["pending", "under_review", "approved", "rejected"]);
const nigerianStates = new Set([
  "Abia", "Adamawa", "Akwa Ibom", "Anambra", "Bauchi", "Bayelsa", "Benue",
  "Borno", "Cross River", "Delta", "Ebonyi", "Edo", "Ekiti", "Enugu", "Gombe",
  "Imo", "Jigawa", "Kaduna", "Kano", "Katsina", "Kebbi", "Kogi", "Kwara",
  "Lagos", "Nasarawa", "Niger", "Ogun", "Ondo", "Osun", "Oyo", "Plateau",
  "Rivers", "Sokoto", "Taraba", "Yobe", "Zamfara", "Federal Capital Territory",
]);
const jsonColumns = new Set(["employment_history"]);
const allowedMimeTypes = new Set([
  "image/jpeg", "image/png", "image/webp", "application/pdf",
]);
const isAllowedUploadType = (mimeType) => {
  const normalizedType = mimeType.trim().toLowerCase();
  const mediaType = normalizedType.split(";", 1)[0].trim();
  return allowedMimeTypes.has(mediaType) || mediaType.startsWith("video/");
};
const isAllowedUpload = (file) => {
  if (isAllowedUploadType(file.mimetype)) return true;
  return file.fieldname.endsWith("_video")
    && /\.(mp4|m4v|mov|webm|mkv|3gp|ogv|avi)$/i.test(file.originalname);
};
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024, files: 4, fields: 4, fieldSize: 1024 * 1024 },
  fileFilter: (_req, file, callback) => {
    if (!isAllowedUpload(file)) {
      callback(Object.assign(new Error("Unsupported file type. Use a JPEG, PNG, WebP, PDF, or a supported video recording."), { status: 400 }));
      return;
    }
    callback(null, true);
  },
});
const logoUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 2 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, callback) => {
    if (!["image/png", "image/jpeg", "image/webp"].includes(file.mimetype)) {
      callback(Object.assign(new Error("Upload a PNG, JPEG, or WebP logo (maximum 2 MB)."), { status: 400 }));
      return;
    }
    callback(null, true);
  },
});

function detectLogoType(buffer) {
  if (buffer.length >= 8 && buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return "image/png";
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return "image/jpeg";
  if (buffer.length >= 12 && buffer.toString("ascii", 0, 4) === "RIFF"
    && buffer.toString("ascii", 8, 12) === "WEBP") return "image/webp";
  return null;
}

const riderInsertColumns = [
  "full_name", "date_of_birth", "place_of_birth", "state_of_origin",
  "state_of_origin_city", "state_of_origin_address", "phone_number",
  "email_address", "residential_address", "residential_state", "residential_city",
  "residential_postal_code", "emergency_contact_name", "emergency_contact_phone",
  "relationship_to_emergency_contact", "marital_status", "has_delivery_experience",
  "employment_history", "communication_skills", "motorcycle_safety", "motorcycle_maintenance",
  "health_challenge", "health_details", "skills_experience", "nin", "nin_document_path",
  "identity_card_front_path", "identity_card_back_path",
  "video_path", "location_latitude", "location_longitude", "location_accuracy_meters",
  "location_captured_at", "work_policy_accepted", "terms_accepted", "terms_signature",
];
const riderEditableColumns = [
  ...riderInsertColumns, "status", "terms_signed_at", "company_representative_signature",
];
const guarantorEditableColumns = [
  "name", "phone_number", "status", "submitted_at", "guarantor_address",
  "guarantor_state", "guarantor_city", "guarantor_postal_code",
  "state_of_origin", "state_of_origin_city", "state_of_origin_address",
  "guarantor_phone_confirmed", "relationship", "occupation", "nin",
  "nin_document_path", "identity_card_front_path",
  "video_path", "digital_signature", "confirmation", "work_policy_accepted",
  "location_latitude", "location_longitude", "location_accuracy_meters",
  "location_captured_at",
];

app.disable("x-powered-by");
app.use(express.json({ limit: "1mb" }));

const asyncRoute = (handler) => (req, res, next) => {
  Promise.resolve(handler(req, res, next)).catch(next);
};

function assertRequired(condition, message) {
  if (!condition) throw Object.assign(new Error(message), { status: 400 });
}

function requireDatabase(_req, res, next) {
  if (!isDatabaseConfigured) {
    return res.status(503).json({
      error: `Aiven connection is not configured. Check ${missingDatabaseConfig.join(", ")} in the server environment.`,
    });
  }
  return next();
}

function cookieValue(req, name) {
  const pair = (req.headers.cookie || "").split(";").map((value) => value.trim())
    .find((value) => value.startsWith(`${name}=`));
  return pair ? decodeURIComponent(pair.slice(name.length + 1)) : "";
}

function hashSession(token) {
  return createHash("sha256").update(token).digest("hex");
}

function cookieOptions(maxAge) {
  return [
    `${sessionCookie}=`,
    "Path=/",
    "HttpOnly",
    "SameSite=Strict",
    `Max-Age=${maxAge}`,
    ...(process.env.NODE_ENV === "production" ? ["Secure"] : []),
  ].join("; ");
}

function ensureSameOrigin(req) {
  const origin = req.get("origin");
  const fetchSite = req.get("sec-fetch-site");
  if (!origin) {
    if (fetchSite === "cross-site") {
      throw Object.assign(new Error("Cross-origin requests are not allowed."), { status: 403 });
    }
    return;
  }
  let parsed;
  try {
    parsed = new URL(origin);
  } catch {
    throw Object.assign(new Error("Request origin is invalid."), { status: 403 });
  }
  const forwardedHost = req.get("x-forwarded-host");
  const host = (forwardedHost ? forwardedHost.split(",", 1)[0] : req.get("host") || "").trim();
  if ((!host || parsed.host.toLowerCase() !== host.toLowerCase()) && fetchSite !== "same-origin") {
    throw Object.assign(new Error("Cross-origin requests are not allowed."), { status: 403 });
  }
}

function limitAdminLogin(req, res, next) {
  const now = Date.now();
  const cutoff = now - 15 * 60 * 1000;
  const key = req.ip || "unknown";
  const attempts = (loginAttempts.get(key) || []).filter((attempt) => attempt > cutoff);
  if (attempts.length >= 10) {
    return res.status(429).json({ error: "Too many sign-in attempts. Try again later." });
  }
  attempts.push(now);
  loginAttempts.set(key, attempts);
  if (loginAttempts.size > 5000) {
    for (const [ip, entries] of loginAttempts) {
      if (!entries.some((attempt) => attempt > cutoff)) loginAttempts.delete(ip);
    }
  }
  return next();
}

const requireAdmin = asyncRoute(async (req, res, next) => {
  const token = cookieValue(req, sessionCookie);
  if (!token) return res.status(401).json({ error: "Administrator sign-in is required." });

  const { rows } = await pool.query(
    `select u.id, u.email
     from admin_sessions s
     join admin_users u on u.id = s.admin_user_id
     where s.session_hash = $1 and s.expires_at > now()`,
    [hashSession(token)],
  );
  if (!rows[0]) {
    res.setHeader("Set-Cookie", cookieOptions(0));
    return res.status(401).json({ error: "Administrator session expired. Please sign in again." });
  }
  req.admin = rows[0];
  return next();
});

function parseJsonField(req, field) {
  try {
    return JSON.parse(req.body[field] || "");
  } catch {
    throw Object.assign(new Error(`Invalid ${field} data.`), { status: 400 });
  }
}

function encryptTelegramCredentials(credentials) {
  const key = telegramEncryptionKey();
  if (!key) throw Object.assign(new Error("Telegram settings are unavailable until TELEGRAM_SETTINGS_ENCRYPTION_KEY is configured as a base64-encoded 32-byte key."), { status: 503 });
  const nonce = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, nonce);
  const encrypted = Buffer.concat([
    cipher.update(JSON.stringify(credentials), "utf8"),
    cipher.final(),
  ]);
  return { encrypted, nonce, authTag: cipher.getAuthTag() };
}

function decryptTelegramCredentials(row) {
  const key = telegramEncryptionKey();
  if (!key) throw Object.assign(new Error("Telegram settings cannot be decrypted. Configure the original TELEGRAM_SETTINGS_ENCRYPTION_KEY."), { status: 503 });
  const decipher = createDecipheriv("aes-256-gcm", key, row.nonce);
  decipher.setAuthTag(row.auth_tag);
  const plaintext = Buffer.concat([
    decipher.update(row.encrypted_credentials),
    decipher.final(),
  ]).toString("utf8");
  return JSON.parse(plaintext);
}

function cleanTelegramValue(value, maxLength) {
  return value.replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, maxLength);
}

async function sendRiderTelegramNotification(rider, riderId, guarantors) {
  const { rows } = await pool.query(
    "select encrypted_credentials, nonce, auth_tag from telegram_settings where id = 1",
  );
  if (!rows[0]) return "not_configured";

  const { bot_token: botToken, chat_id: chatId } = decryptTelegramCredentials(rows[0]);
  const text = [
    "New rider application received",
    `Application ID: ${riderId}`,
    `Name: ${cleanTelegramValue(rider.full_name, 200)}`,
    `Phone: ${cleanTelegramValue(rider.phone_number, 80)}`,
    `Email: ${cleanTelegramValue(rider.email_address || "Not provided", 200)}`,
    `State of origin: ${cleanTelegramValue(rider.state_of_origin, 100)}`,
    `Origin city: ${cleanTelegramValue(rider.state_of_origin_city, 150)}`,
    `Residential location: ${cleanTelegramValue(`${rider.residential_city}, ${rider.residential_state}`, 250)}`,
    ...guarantors.map((guarantor, index) =>
      `Guarantor ${index + 1}: ${cleanTelegramValue(guarantor.name, 200)} (${cleanTelegramValue(guarantor.phone_number, 80)})`),
    `Submitted: ${new Date().toISOString()}`,
  ].join("\n");

  const response = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text }),
    signal: AbortSignal.timeout(10000),
  });
  if (!response.ok) throw Object.assign(new Error("Telegram rejected the notification."), { code: `telegram_http_${response.status}` });
  const result = await response.json();
  if (result.ok !== true) throw Object.assign(new Error("Telegram rejected the notification."), { code: "telegram_api_rejected" });
  return "sent";
}

function validateLocation(payload) {
  const latitude = Number(payload.location_latitude);
  const longitude = Number(payload.location_longitude);
  const accuracy = Number(payload.location_accuracy_meters);
  const capturedAt = Date.parse(payload.location_captured_at);
  assertRequired(
    Number.isFinite(latitude) && latitude >= -90 && latitude <= 90
      && Number.isFinite(longitude) && longitude >= -180 && longitude <= 180
      && Number.isFinite(accuracy) && accuracy >= 0
      && Number.isFinite(capturedAt),
    "Location permission is required to submit. Allow location access and try again.",
  );
}

function validateRider(rider, guarantors, files) {
  assertRequired(rider && typeof rider === "object" && !Array.isArray(rider), "Rider details are required.");
  assertRequired(typeof rider.full_name === "string" && rider.full_name.trim(), "Rider name is required.");
  assertRequired(typeof rider.phone_number === "string" && rider.phone_number.trim(), "Rider phone is required.");
  assertRequired(nigerianStates.has(rider.state_of_origin), "Select a valid Nigerian state or the Federal Capital Territory.");
  assertRequired(typeof rider.state_of_origin_city === "string" && rider.state_of_origin_city.trim()
    && typeof rider.state_of_origin_address === "string" && rider.state_of_origin_address.trim(), "State of origin city and address are required.");
  assertRequired(nigerianStates.has(rider.residential_state) && typeof rider.residential_city === "string" && rider.residential_city.trim(), "Select a residential state and city or area.");
  assertRequired(typeof rider.nin === "string" && /^\d{11}$/.test(rider.nin), "Rider NIN must contain exactly 11 digits.");
  assertRequired(files.ninDocument, "Rider NIN document is required.");
  assertRequired(files.identityCardFront, "Rider identity card front scan is required.");
  assertRequired(files.identityCardBack, "Rider identity card back scan is required.");
  assertRequired(files.video, "Rider video verification is required.");
  assertRequired(rider.work_policy_accepted === true, "Rider must accept the earnings and work policy.");
  assertRequired(rider.terms_accepted === true && typeof rider.terms_signature === "string" && rider.terms_signature.trim(), "Terms acceptance and signature are required.");
  for (const key of ["has_delivery_experience", "communication_skills", "motorcycle_safety", "motorcycle_maintenance", "health_challenge"]) {
    assertRequired(typeof rider[key] === "boolean", "Please answer every experience and skills question.");
  }
  assertRequired(Array.isArray(rider.employment_history), "Employment history must be a list.");
  assertRequired(Array.isArray(guarantors) && guarantors.length === 2, "Exactly two guarantors are required.");
  assertRequired(guarantors.every((item) => typeof item?.name === "string" && item.name.trim()
    && typeof item?.phone_number === "string" && item.phone_number.trim()), "Both guarantor names and phone numbers are required.");
  validateLocation(rider);
  return rider;
}

function validateGuarantor(payload, files) {
  assertRequired(payload && typeof payload === "object" && !Array.isArray(payload), "Guarantor details are required.");
  for (const key of ["guarantor_address", "guarantor_state", "guarantor_city", "state_of_origin",
    "state_of_origin_city", "state_of_origin_address", "guarantor_phone_confirmed",
    "relationship", "occupation", "digital_signature"]) {
    assertRequired(typeof payload[key] === "string" && payload[key].trim(), "Required guarantor information and signature must be provided.");
  }
  assertRequired(nigerianStates.has(payload.guarantor_state), "Select a valid Nigerian residential state.");
  assertRequired(nigerianStates.has(payload.state_of_origin), "Select a valid state of origin.");
  assertRequired(typeof payload.nin === "string" && /^\d{11}$/.test(payload.nin), "Guarantor NIN must contain exactly 11 digits.");
  assertRequired(files.ninDocument, "Guarantor NIN document is required.");
  assertRequired(files.video, "Guarantor video verification is required.");
  assertRequired(payload.confirmation === true, "Guarantor confirmation is required.");
  assertRequired(payload.work_policy_accepted === true, "Guarantor must accept the rider work policy.");
  validateLocation(payload);
  return payload;
}

async function insertFile(client, file) {
  if (!file) return null;
  const { rows } = await client.query(
    `insert into application_files (filename, content_type, size_bytes, file_data)
     values ($1, $2, $3, $4) returning id`,
    [file.originalname.slice(0, 255), file.mimetype, file.size, file.buffer],
  );
  return rows[0].id;
}

function insertValue(column, value) {
  if (column === "date_of_birth" || column.endsWith("_at")) return value || null;
  return jsonColumns.has(column) ? JSON.stringify(value ?? []) : value ?? null;
}

function buildUpdateStatement(table, idColumn, id, fields, allowedColumns) {
  const entries = Object.entries(fields).filter(([key]) => allowedColumns.includes(key));
  if (!entries.length) return null;
  const setClauses = entries.map(([key], index) =>
    `${key} = $${index + 1}${jsonColumns.has(key) ? "::jsonb" : ""}`,
  );
  const values = entries.map(([key, value]) => insertValue(key, value));
  values.push(id);
  return {
    text: `update ${table} set ${setClauses.join(", ")}${table === "riders" ? ", updated_at = now()" : ""} where ${idColumn} = $${values.length}`,
    values,
  };
}

function collectFileIds(record) {
  const ids = new Set();
  const visit = (value) => {
    if (!value || typeof value !== "object") return;
    for (const [key, item] of Object.entries(value)) {
      if (typeof item === "string" && key.endsWith("_path") && /^[0-9a-f-]{36}$/i.test(item)) ids.add(item);
      else if (Array.isArray(item)) item.forEach(visit);
      else if (item && typeof item === "object") visit(item);
    }
  };
  visit(record);
  return [...ids];
}

app.get("/api/health", asyncRoute(async (_req, res) => {
  if (!isDatabaseConfigured) {
    return res.status(503).json({ status: "not_configured", database: false, missing: missingDatabaseConfig });
  }
  await pool.query("select 1");
  const { rows } = await pool.query(
    `select to_regclass('public.riders') is not null as riders,
            to_regclass('public.guarantors') is not null as guarantors,
            to_regclass('public.admin_users') is not null as admin_users,
            to_regclass('public.application_files') is not null as application_files`,
  );
  const schemaReady = Object.values(rows[0]).every(Boolean);
  return res.status(schemaReady ? 200 : 503).json({
    status: schemaReady ? "ok" : "schema_missing",
    database: true,
    schema: schemaReady,
  });
}));

app.get("/api/company-logo", requireDatabase, asyncRoute(async (_req, res) => {
  res.setHeader("Cache-Control", "no-store");
  const { rows } = await pool.query("select content_type, image_data from company_branding where id = 1");
  const logo = rows[0];
  if (!logo) return res.status(404).end();
  res.setHeader("Content-Type", logo.content_type);
  res.setHeader("X-Content-Type-Options", "nosniff");
  return res.send(logo.image_data);
}));

app.get("/api/form-content", requireDatabase, asyncRoute(async (_req, res) => {
  const { rows } = await pool.query("select content from form_content where id = 1");
  return res.json(rows[0]?.content ?? {});
}));

app.get("/api/guarantors/:token", requireDatabase, asyncRoute(async (req, res) => {
  const { rows } = await pool.query(
    `select g.id, g.status, r.full_name as rider_name,
            g.name as guarantor_name, g.phone_number as guarantor_phone
     from guarantors g join riders r on r.id = g.rider_id
     where g.verification_token = $1`,
    [req.params.token],
  );
  if (!rows[0]) return res.status(404).json({ error: "Verification link not found." });
  return res.json(rows[0]);
}));

app.post("/api/applications", requireDatabase, upload.fields([
  { name: "rider_nin_document", maxCount: 1 },
  { name: "rider_identity_card_front", maxCount: 1 },
  { name: "rider_identity_card_back", maxCount: 1 },
  { name: "rider_video", maxCount: 1 },
]), asyncRoute(async (req, res) => {
  const rider = parseJsonField(req, "rider");
  const guarantors = parseJsonField(req, "guarantors");
  const files = {
    ninDocument: req.files?.rider_nin_document?.[0],
    identityCardFront: req.files?.rider_identity_card_front?.[0],
    identityCardBack: req.files?.rider_identity_card_back?.[0],
    video: req.files?.rider_video?.[0],
  };
  validateRider(rider, guarantors, files);
  const client = await pool.connect();
  let riderId;
  const createdGuarantors = [];
  try {
    await client.query("begin");
    const documentId = await insertFile(client, files.ninDocument);
    const identityCardFrontId = await insertFile(client, files.identityCardFront);
    const identityCardBackId = await insertFile(client, files.identityCardBack);
    const videoId = await insertFile(client, files.video);
    const application = {
      ...rider,
      nin_document_path: documentId,
      identity_card_front_path: identityCardFrontId,
      identity_card_back_path: identityCardBackId,
      video_path: videoId,
    };
    const columns = riderInsertColumns;
    const values = columns.map((column) => insertValue(column, application[column]));
    const placeholders = columns.map((column, index) => `${jsonColumns.has(column) ? `$${index + 1}::jsonb` : `$${index + 1}`}`);
    const { rows: riderRows } = await client.query(
      `insert into riders (${columns.join(", ")}) values (${placeholders.join(", ")}) returning id`,
      values,
    );
    riderId = riderRows[0].id;
    for (const guarantor of guarantors) {
      const { rows } = await client.query(
        `insert into guarantors (rider_id, name, phone_number)
         values ($1, $2, $3)
         returning id, name, phone_number, verification_token`,
        [riderId, guarantor.name.trim(), guarantor.phone_number.trim()],
      );
      createdGuarantors.push(rows[0]);
    }
    await client.query("commit");
  } catch (error) {
    await client.query("rollback");
    throw error;
  } finally {
    client.release();
  }
  let telegramNotification = "not_configured";
  try {
    telegramNotification = await sendRiderTelegramNotification(rider, riderId, createdGuarantors);
  } catch (error) {
    telegramNotification = "failed";
    console.error("Rider application was saved, but Telegram notification failed.", {
      code: error.code || "telegram_notification_failed",
    });
  }
  return res.status(201).json({
    rider_id: riderId,
    guarantors: createdGuarantors,
    telegram_notification: telegramNotification,
  });
}));

app.post("/api/guarantors/:token", requireDatabase, upload.fields([
  { name: "guarantor_nin_document", maxCount: 1 },
  { name: "guarantor_video", maxCount: 1 },
]), asyncRoute(async (req, res) => {
  const payload = parseJsonField(req, "payload");
  const files = {
    ninDocument: req.files?.guarantor_nin_document?.[0],
    video: req.files?.guarantor_video?.[0],
  };
  validateGuarantor(payload, files);
  const client = await pool.connect();
  try {
    await client.query("begin");
    const documentId = await insertFile(client, files.ninDocument);
    const videoId = await insertFile(client, files.video);
    const { rowCount } = await client.query(
      `update guarantors set
         status = 'submitted', submitted_at = now(),
         guarantor_address = $1, guarantor_phone_confirmed = $2,
         guarantor_state = $3, guarantor_city = $4, guarantor_postal_code = $5,
         state_of_origin = $6, state_of_origin_city = $7, state_of_origin_address = $8,
         relationship = $9, occupation = $10, nin = $11,
         nin_document_path = $12, video_path = $13, digital_signature = $14,
         confirmation = true, work_policy_accepted = $15,
         location_latitude = $16, location_longitude = $17,
         location_accuracy_meters = $18, location_captured_at = $19
       where verification_token = $20 and status = 'pending'`,
      [
        payload.guarantor_address, payload.guarantor_phone_confirmed,
        payload.guarantor_state, payload.guarantor_city, payload.guarantor_postal_code || "",
        payload.state_of_origin, payload.state_of_origin_city, payload.state_of_origin_address,
        payload.relationship, payload.occupation, payload.nin, documentId,
        videoId, payload.digital_signature, payload.work_policy_accepted, payload.location_latitude,
        payload.location_longitude, payload.location_accuracy_meters,
        payload.location_captured_at, req.params.token,
      ],
    );
    if (rowCount !== 1) {
      await client.query("rollback");
      return res.status(409).json({ error: "This verification link has already been used or is invalid." });
    }
    await client.query("commit");
    return res.json({ success: true });
  } catch (error) {
    await client.query("rollback");
    throw error;
  } finally {
    client.release();
  }
}));

app.post("/api/admin/login", requireDatabase, limitAdminLogin, asyncRoute(async (req, res) => {
  ensureSameOrigin(req);
  const email = typeof req.body?.email === "string" ? req.body.email.trim().toLowerCase() : "";
  const password = typeof req.body?.password === "string" ? req.body.password : "";
  assertRequired(email && password, "Email and password are required.");
  assertRequired(password.length <= 1024, "Password is too long.");
  const { rows } = await pool.query("select id, password_hash from admin_users where email = $1", [email]);
  const admin = rows[0];
  const validPassword = admin ? await compare(password, admin.password_hash) : false;
  if (!validPassword) return res.status(401).json({ error: "Email or password is incorrect." });

  const token = randomBytes(32).toString("base64url");
  await pool.query("delete from admin_sessions where expires_at <= now()");
  await pool.query(
    "insert into admin_sessions (admin_user_id, session_hash, expires_at) values ($1, $2, now() + interval '12 hours')",
    [admin.id, hashSession(token)],
  );
  res.setHeader("Set-Cookie", `${sessionCookie}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${sessionDurationSeconds}${process.env.NODE_ENV === "production" ? "; Secure" : ""}`);
  return res.json({ success: true });
}));

app.get("/api/admin/registration-status", requireDatabase, asyncRoute(async (req, res) => {
  const token = cookieValue(req, sessionCookie);
  const { rows } = await pool.query(
    `select (select count(*) from admin_users) = 0 as bootstrap_open,
            exists (
              select 1 from admin_sessions s
              join admin_users u on u.id = s.admin_user_id
              where s.session_hash = $1 and s.expires_at > now()
            ) as authenticated`,
    [token ? hashSession(token) : ""],
  );
  return res.json(rows[0]);
}));

app.post("/api/admin/register", requireDatabase, limitAdminLogin, asyncRoute(async (req, res) => {
  ensureSameOrigin(req);
  const email = typeof req.body?.email === "string" ? req.body.email.trim().toLowerCase() : "";
  const password = typeof req.body?.password === "string" ? req.body.password : "";
  assertRequired(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254, "Enter a valid email address.");
  assertRequired(password.length >= 12 && password.length <= 1024, "Password must be at least 12 characters.");

  const client = await pool.connect();
  let createdAdmin;
  let bootstrap = false;
  try {
    await client.query("begin");
    await client.query("select pg_advisory_xact_lock(60824011)");
    const { rows: countRows } = await client.query("select count(*)::int as count from admin_users");
    bootstrap = countRows[0].count === 0;
    if (!bootstrap) {
      const token = cookieValue(req, sessionCookie);
      const { rows: adminRows } = await client.query(
        `select u.id from admin_sessions s
         join admin_users u on u.id = s.admin_user_id
         where s.session_hash = $1 and s.expires_at > now()`,
        [token ? hashSession(token) : ""],
      );
      if (!adminRows[0]) {
        throw Object.assign(new Error("Only a signed-in administrator can register another administrator."), { status: 401 });
      }
    }
    const passwordHash = await hash(password, 12);
    const { rows } = await client.query(
      "insert into admin_users (email, password_hash) values ($1, $2) returning id",
      [email, passwordHash],
    );
    createdAdmin = rows[0];
    await client.query("commit");
  } catch (error) {
    await client.query("rollback");
    if (error.code === "23505") {
      throw Object.assign(new Error("An administrator with this email already exists."), { status: 409 });
    }
    throw error;
  } finally {
    client.release();
  }

  if (bootstrap) {
    const token = randomBytes(32).toString("base64url");
    await pool.query(
      "insert into admin_sessions (admin_user_id, session_hash, expires_at) values ($1, $2, now() + interval '12 hours')",
      [createdAdmin.id, hashSession(token)],
    );
    res.setHeader("Set-Cookie", `${sessionCookie}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${sessionDurationSeconds}${process.env.NODE_ENV === "production" ? "; Secure" : ""}`);
  }
  return res.status(201).json({ success: true, bootstrap });
}));

app.post("/api/admin/logout", requireDatabase, asyncRoute(async (req, res) => {
  ensureSameOrigin(req);
  const token = cookieValue(req, sessionCookie);
  if (token) await pool.query("delete from admin_sessions where session_hash = $1", [hashSession(token)]);
  res.setHeader("Set-Cookie", cookieOptions(0));
  return res.json({ success: true });
}));

app.get("/api/admin/me", requireDatabase, requireAdmin, (req, res) => {
  res.json({ user_id: req.admin.id, email: req.admin.email });
});

app.get("/api/admin/riders", requireDatabase, requireAdmin, asyncRoute(async (_req, res) => {
  const { rows } = await pool.query(
    `select r.*,
       coalesce(json_agg(g order by g.created_at) filter (where g.id is not null), '[]'::json) as guarantors
     from riders r left join guarantors g on g.rider_id = r.id
     group by r.id order by r.created_at desc`,
  );
  return res.json(rows);
}));

app.get("/api/admin/form-content", requireDatabase, requireAdmin, asyncRoute(async (_req, res) => {
  const { rows } = await pool.query("select content from form_content where id = 1");
  return res.json(rows[0]?.content ?? {});
}));

app.get("/api/admin/telegram-settings", requireDatabase, requireAdmin, asyncRoute(async (_req, res) => {
  const { rows } = await pool.query("select exists(select 1 from telegram_settings where id = 1) as configured");
  return res.json({
    configured: rows[0].configured,
    encryption_key_configured: Boolean(telegramEncryptionKey()),
  });
}));

app.put("/api/admin/telegram-settings", requireDatabase, requireAdmin, asyncRoute(async (req, res) => {
  ensureSameOrigin(req);
  const botToken = typeof req.body?.bot_token === "string" ? req.body.bot_token.trim() : "";
  const chatId = typeof req.body?.chat_id === "string" ? req.body.chat_id.trim() : "";
  assertRequired(/^\d{6,}:[A-Za-z0-9_-]{20,}$/.test(botToken) && botToken.length <= 256, "Enter a valid Telegram bot token.");
  assertRequired(/^(?:-?\d{1,20}|@[A-Za-z0-9_]{5,32})$/.test(chatId), "Enter a numeric Telegram chat ID or @channel username.");
  const encrypted = encryptTelegramCredentials({ bot_token: botToken, chat_id: chatId });
  await pool.query(
    `insert into telegram_settings (id, encrypted_credentials, nonce, auth_tag, updated_by)
     values (1, $1, $2, $3, $4)
     on conflict (id) do update
       set encrypted_credentials = excluded.encrypted_credentials,
           nonce = excluded.nonce, auth_tag = excluded.auth_tag,
           updated_by = excluded.updated_by, updated_at = now()`,
    [encrypted.encrypted, encrypted.nonce, encrypted.authTag, req.admin.id],
  );
  return res.json({ success: true });
}));

app.delete("/api/admin/telegram-settings", requireDatabase, requireAdmin, asyncRoute(async (req, res) => {
  ensureSameOrigin(req);
  await pool.query("delete from telegram_settings where id = 1");
  return res.json({ success: true });
}));

app.put("/api/admin/form-content", requireDatabase, requireAdmin, asyncRoute(async (req, res) => {
  ensureSameOrigin(req);
  const content = req.body?.content;
  assertRequired(content && typeof content === "object" && !Array.isArray(content), "Form content must be an object.");
  const entries = Object.entries(content);
  assertRequired(entries.length <= 300, "Too many form content entries.");
  for (const [key, value] of entries) {
    assertRequired(typeof key === "string" && key.length <= 10000, "A form content key is invalid.");
    assertRequired(typeof value === "string" && value.length <= 10000, `Form content "${key}" must be text of 10,000 characters or less.`);
  }
  await pool.query(
    `insert into form_content (id, content, updated_by)
     values (1, $1::jsonb, $2)
     on conflict (id) do update
       set content = excluded.content, updated_by = excluded.updated_by, updated_at = now()`,
    [JSON.stringify(content), req.admin.id],
  );
  return res.json({ success: true });
}));

app.put("/api/admin/company-logo", requireDatabase, requireAdmin, (req, res, next) => {
  ensureSameOrigin(req);
  logoUpload.single("logo")(req, res, (error) => {
    if (error) return next(error);
    return next();
  });
}, asyncRoute(async (req, res) => {
  assertRequired(req.file, "Choose a company logo to upload.");
  const contentType = detectLogoType(req.file.buffer);
  assertRequired(contentType, "The uploaded file is not a valid PNG, JPEG, or WebP image.");
  await pool.query(
    `insert into company_branding (id, content_type, image_data, updated_by)
     values (1, $1, $2, $3)
     on conflict (id) do update
       set content_type = excluded.content_type, image_data = excluded.image_data,
           updated_by = excluded.updated_by, updated_at = now()`,
    [contentType, req.file.buffer, req.admin.id],
  );
  return res.json({ success: true });
}));

app.delete("/api/admin/company-logo", requireDatabase, requireAdmin, asyncRoute(async (req, res) => {
  ensureSameOrigin(req);
  await pool.query("delete from company_branding where id = 1");
  return res.json({ success: true });
}));

app.put("/api/admin/riders/:id", requireDatabase, requireAdmin, asyncRoute(async (req, res) => {
  ensureSameOrigin(req);
  const record = req.body;
  assertRequired(record && record.id === req.params.id, "Record ID cannot be changed.");
  assertRequired(statuses.has(record.status), "Application status is invalid.");
  assertRequired(Array.isArray(record.guarantors), "Guarantors must be a list.");
  const client = await pool.connect();
  try {
    await client.query("begin");
    const riderUpdate = buildUpdateStatement("riders", "id", req.params.id, record, riderEditableColumns);
    if (riderUpdate) {
      const result = await client.query(riderUpdate.text, riderUpdate.values);
      assertRequired(result.rowCount === 1, "Application not found.");
    }
    const { rows: current } = await client.query("select id from guarantors where rider_id = $1", [req.params.id]);
    const existingIds = new Set(current.map((row) => row.id));
    const keepIds = new Set();
    for (const guarantor of record.guarantors) {
      assertRequired(typeof guarantor.name === "string" && guarantor.name.trim()
        && typeof guarantor.phone_number === "string" && guarantor.phone_number.trim(), "Guarantor name and phone are required.");
      if (typeof guarantor.id === "string" && existingIds.has(guarantor.id)) {
        keepIds.add(guarantor.id);
        const update = buildUpdateStatement("guarantors", "id", guarantor.id, guarantor, guarantorEditableColumns);
        if (update) await client.query(`${update.text} and rider_id = $${update.values.length + 1}`, [...update.values, req.params.id]);
      } else {
        const fields = Object.entries(guarantor).filter(([key]) => guarantorEditableColumns.includes(key));
        const columns = ["rider_id", ...fields.map(([key]) => key)];
        const values = [req.params.id, ...fields.map(([key, value]) => insertValue(key, value))];
        const placeholders = values.map((_, index) => `$${index + 1}`);
        await client.query(`insert into guarantors (${columns.join(", ")}) values (${placeholders.join(", ")})`, values);
      }
    }
    const removed = [...existingIds].filter((id) => !keepIds.has(id));
    if (removed.length) {
      const { rows: oldFiles } = await client.query(
        "select nin_document_path, identity_card_front_path, identity_card_back_path, video_path from guarantors where id = any($1::uuid[])",
        [removed],
      );
      const fileIds = collectFileIds(oldFiles);
      await client.query("delete from guarantors where rider_id = $1 and id = any($2::uuid[])", [req.params.id, removed]);
      if (fileIds.length) await client.query("delete from application_files where id = any($1::uuid[])", [fileIds]);
    }
    await client.query("commit");
    return res.json({ success: true });
  } catch (error) {
    await client.query("rollback");
    throw error;
  } finally {
    client.release();
  }
}));

app.patch("/api/admin/riders/:id/status", requireDatabase, requireAdmin, asyncRoute(async (req, res) => {
  ensureSameOrigin(req);
  const { status } = req.body ?? {};
  assertRequired(statuses.has(status), "Application status is invalid.");
  const { rowCount } = await pool.query("update riders set status = $1, updated_at = now() where id = $2", [status, req.params.id]);
  if (rowCount !== 1) return res.status(404).json({ error: "Application not found." });
  return res.json({ success: true });
}));

app.get("/api/admin/files/:id", requireDatabase, requireAdmin, asyncRoute(async (req, res) => {
  assertRequired(/^[0-9a-f-]{36}$/i.test(req.params.id), "File ID is invalid.");
  const { rows } = await pool.query(
    "select filename, content_type, file_data from application_files where id = $1",
    [req.params.id],
  );
  const file = rows[0];
  if (!file) return res.status(404).json({ error: "Uploaded file not found." });
  const filename = encodeURIComponent(file.filename).replace(/['()*]/g, (character) =>
    `%${character.charCodeAt(0).toString(16).toUpperCase()}`,
  );
  res.setHeader("Content-Type", file.content_type);
  res.setHeader("Content-Disposition", `inline; filename*=UTF-8''${filename}`);
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Content-Security-Policy", "sandbox");
  return res.send(file.file_data);
}));

app.delete("/api/admin/riders/:id", requireDatabase, requireAdmin, asyncRoute(async (req, res) => {
  ensureSameOrigin(req);
  const client = await pool.connect();
  try {
    await client.query("begin");
    const { rows: riderRows } = await client.query(
      "select nin_document_path, identity_card_front_path, identity_card_back_path, video_path from riders where id = $1 for update",
      [req.params.id],
    );
    if (!riderRows[0]) {
      await client.query("rollback");
      return res.status(404).json({ error: "Application not found." });
    }
    const { rows: guarantorRows } = await client.query(
      "select nin_document_path, identity_card_front_path, identity_card_back_path, video_path from guarantors where rider_id = $1",
      [req.params.id],
    );
    const fileIds = collectFileIds([...riderRows, ...guarantorRows]);
    await client.query("delete from riders where id = $1", [req.params.id]);
    if (fileIds.length) await client.query("delete from application_files where id = any($1::uuid[])", [fileIds]);
    await client.query("commit");
    return res.json({ success: true });
  } catch (error) {
    await client.query("rollback");
    throw error;
  } finally {
    client.release();
  }
}));

app.use("/api", (_req, res) => res.status(404).json({ error: "API route not found." }));

if (process.env.NODE_ENV === "production") {
  app.use(express.static(resolve("dist")));
  app.get(/.*/, (_req, res) => res.sendFile(resolve("dist/index.html")));
}

app.use((error, req, res, _next) => {
  const status = error instanceof multer.MulterError
    ? error.code === "LIMIT_FILE_SIZE" ? 413 : 400
    : Number.isInteger(error.status) ? error.status : 500;
  if (status >= 500) console.error("API request failed", { path: req.path, code: error.code || "unexpected_error" });
  return res.status(status).json({
    error: status < 500 ? error.message : "The request could not be completed.",
  });
});

app.listen(port, () => {
  console.log(`Vanguard Velocity API listening on port ${port}`);
  if (!isDatabaseConfigured) console.error(`Aiven database is not configured; missing ${missingDatabaseConfig.join(", ")}.`);
});
